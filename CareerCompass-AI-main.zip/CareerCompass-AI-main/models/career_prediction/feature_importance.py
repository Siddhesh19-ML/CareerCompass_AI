import joblib
import pandas as pd
import os


MODEL_PATH = "models/career_prediction/saved_model/career_model.pkl"

model = joblib.load(MODEL_PATH)

print("\n" + "=" * 60)
print("XGBOOST FEATURE IMPORTANCE")
print("=" * 60)

# Get feature names from the model
feature_names = model.get_booster().feature_names

importance = model.feature_importances_

df = pd.DataFrame({
    "feature": feature_names,
    "importance": importance
})

df = df.sort_values(
    by="importance",
    ascending=False
)

print("\nTOP 30 FEATURES")
print("-" * 60)

for _, row in df.head(30).iterrows():
    print(
        f"{row['feature']:30s} "
        f"{row['importance']:.6f}"
    )

# Save results
output_path = (
    "models/career_prediction/"
    "feature_importance.csv"
)

df.to_csv(output_path, index=False)

print("\n" + "=" * 60)
print("Saved to:")
print(output_path)
print("=" * 60)