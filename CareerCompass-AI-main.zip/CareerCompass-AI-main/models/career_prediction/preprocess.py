import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


# ==============================
# 1. LOAD DATASET
# ==============================

DATA_PATH = "dataset/students_v2.csv"

df = pd.read_csv(DATA_PATH)

print("Dataset loaded successfully!")
print("Shape:", df.shape)


# ==============================
# 2. REMOVE UNNECESSARY COLUMNS
# ==============================

# student_id has no predictive value
# desired_career is intentionally excluded because
# we want the model to independently predict the best career.

df = df.drop(columns=["student_id", "desired_career"])


# ==============================
# 3. SEPARATE FEATURES AND TARGET
# ==============================

X = df.drop(columns=["actual_best_career"])
y = df["actual_best_career"]


# ==============================
# 4. ENCODE CATEGORICAL FEATURES
# ==============================

categorical_columns = X.select_dtypes(
    include=["object"]
).columns

X = pd.get_dummies(
    X,
    columns=categorical_columns,
    dtype=int
)


# ==============================
# 5. ENCODE TARGET LABEL
# ==============================

label_encoder = LabelEncoder()

y_encoded = label_encoder.fit_transform(y)

print("\nCareer classes:")
for i, career in enumerate(label_encoder.classes_):
    print(i, "->", career)


# ==============================
# 6. TRAIN / TEST SPLIT
# ==============================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y_encoded,
    test_size=0.20,
    random_state=42,
    stratify=y_encoded
)


# ==============================
# 7. DISPLAY INFORMATION
# ==============================

print("\nPreprocessing completed!")

print("Total features:", X.shape[1])

print("Training samples:", X_train.shape[0])
print("Testing samples:", X_test.shape[0])

print("\nTraining data shape:", X_train.shape)
print("Testing data shape:", X_test.shape)


# ==============================
# 8. RETURN DATA
# ==============================

def get_processed_data():

    return (
        X_train,
        X_test,
        y_train,
        y_test,
        label_encoder,
        X.columns
    )