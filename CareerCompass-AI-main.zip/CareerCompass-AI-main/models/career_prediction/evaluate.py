import os
import joblib
from sklearn.metrics import accuracy_score, classification_report

from preprocess import get_processed_data


# ==========================================
# 1. LOAD TEST DATA
# ==========================================

X_train, X_test, y_train, y_test, label_encoder, feature_columns = (
    get_processed_data()
)


# ==========================================
# 2. MODEL PATHS
# ==========================================

MODEL_DIR = os.path.join(
    os.path.dirname(__file__),
    "saved_model"
)

baseline_path = os.path.join(
    MODEL_DIR,
    "career_model.pkl"
)

tuned_path = os.path.join(
    MODEL_DIR,
    "career_model_tuned.pkl"
)


# ==========================================
# 3. LOAD MODELS
# ==========================================

baseline_model = joblib.load(baseline_path)
tuned_model = joblib.load(tuned_path)

print("Both models loaded successfully!")


# ==========================================
# 4. PREDICTIONS
# ==========================================

baseline_pred = baseline_model.predict(X_test)
tuned_pred = tuned_model.predict(X_test)


# ==========================================
# 5. EVALUATE BASELINE
# ==========================================

baseline_accuracy = accuracy_score(
    y_test,
    baseline_pred
)

print("\n" + "=" * 60)
print("BASELINE MODEL")
print("=" * 60)

print(f"\nAccuracy: {baseline_accuracy * 100:.2f}%")

print("\nClassification Report:\n")

print(
    classification_report(
        y_test,
        baseline_pred,
        target_names=label_encoder.classes_
    )
)


# ==========================================
# 6. EVALUATE TUNED MODEL
# ==========================================

tuned_accuracy = accuracy_score(
    y_test,
    tuned_pred
)

print("\n" + "=" * 60)
print("TUNED MODEL")
print("=" * 60)

print(f"\nAccuracy: {tuned_accuracy * 100:.2f}%")

print("\nClassification Report:\n")

print(
    classification_report(
        y_test,
        tuned_pred,
        target_names=label_encoder.classes_
    )
)


# ==========================================
# 7. COMPARISON
# ==========================================

print("\n" + "=" * 60)
print("MODEL COMPARISON")
print("=" * 60)

print(
    f"\nBaseline Accuracy : {baseline_accuracy * 100:.2f}%"
)

print(
    f"Tuned Accuracy    : {tuned_accuracy * 100:.2f}%"
)

difference = (
    tuned_accuracy - baseline_accuracy
) * 100

print(
    f"Difference        : {difference:+.2f}%"
)