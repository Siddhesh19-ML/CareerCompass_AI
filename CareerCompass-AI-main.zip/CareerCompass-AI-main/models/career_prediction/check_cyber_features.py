import joblib

MODEL_PATH = "models/career_prediction/saved_model/career_model.pkl"

model = joblib.load(MODEL_PATH)

feature_names = model.get_booster().feature_names
importance = model.feature_importances_

cyber_features = [
    "linux",
    "networking",
    "bash",
    "nmap",
    "wireshark",
    "burpsuite",
    "kali_linux",
    "owasp",
    "cryptography",
    "metasploit",
    "cn_score",
    "os_score",
]

results = []

for feature, value in zip(feature_names, importance):
    if feature in cyber_features:
        results.append((feature, value))

results.sort(key=lambda x: x[1], reverse=True)

print("\n" + "=" * 50)
print("CYBERSECURITY FEATURE IMPORTANCE")
print("=" * 50)

for feature, value in results:
    print(f"{feature:20s} {value:.6f}")