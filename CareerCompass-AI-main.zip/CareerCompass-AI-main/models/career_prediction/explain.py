import os
import joblib
import pandas as pd
import shap

from preprocess import get_processed_data


# ==========================================
# 1. LOAD DATA AND MODEL
# ==========================================

X_train, X_test, y_train, y_test, label_encoder, feature_columns = (
    get_processed_data()
)

MODEL_DIR = os.path.join(
    os.path.dirname(__file__),
    "saved_model"
)

model = joblib.load(
    os.path.join(MODEL_DIR, "career_model.pkl")
)

print("Model loaded successfully!")


# ==========================================
# 2. SELECT ONE STUDENT
# ==========================================

# For now, explain the first student in the test set.
student = X_test.iloc[[0]]

actual_label = y_test[0]

actual_career = label_encoder.inverse_transform(
    [actual_label]
)[0]


# ==========================================
# 3. PREDICT CAREER
# ==========================================

probabilities = model.predict_proba(student)[0]

predicted_index = probabilities.argmax()

predicted_career = label_encoder.inverse_transform(
    [predicted_index]
)[0]

confidence = probabilities[predicted_index] * 100


print("\n" + "=" * 60)
print("INDIVIDUAL CAREER EXPLANATION")
print("=" * 60)

print(f"\nActual Career     : {actual_career}")
print(f"Predicted Career  : {predicted_career}")
print(f"Confidence        : {confidence:.2f}%")


# ==========================================
# 4. CREATE SHAP EXPLAINER
# ==========================================

print("\nCalculating SHAP values...")

explainer = shap.TreeExplainer(model)

shap_values = explainer.shap_values(student)


# ==========================================
# 5. HANDLE MULTI-CLASS SHAP OUTPUT
# ==========================================

if isinstance(shap_values, list):

    # Older SHAP versions:
    # list[class] -> (samples, features)

    student_shap = shap_values[predicted_index][0]

else:

    # Newer SHAP versions:
    # (samples, features, classes)

    if shap_values.ndim == 3:
        student_shap = shap_values[
            0, :, predicted_index
        ]

    else:
        student_shap = shap_values[0]


# ==========================================
# 6. CREATE FEATURE CONTRIBUTION TABLE
# ==========================================

explanation = pd.DataFrame({
    "feature": student.columns,
    "value": student.iloc[0].values,
    "shap_value": student_shap
})

explanation["abs_shap"] = explanation["shap_value"].abs()

explanation = explanation.sort_values(
    "abs_shap",
    ascending=False
)


# ==========================================
# 7. TOP POSITIVE FACTORS
# ==========================================

positive = explanation[
    explanation["shap_value"] > 0
].head(10)


print("\n" + "-" * 60)
print("TOP POSITIVE FACTORS")
print("-" * 60)

for _, row in positive.iterrows():

    print(
        f"+ {row['feature']:<30}"
        f" SHAP: {row['shap_value']:.4f}"
        f"  Value: {row['value']}"
    )


# ==========================================
# 8. TOP NEGATIVE FACTORS
# ==========================================

negative = explanation[
    explanation["shap_value"] < 0
].sort_values(
    "shap_value"
).head(10)


print("\n" + "-" * 60)
print("TOP NEGATIVE FACTORS")
print("-" * 60)

for _, row in negative.iterrows():

    print(
        f"- {row['feature']:<30}"
        f" SHAP: {row['shap_value']:.4f}"
        f"  Value: {row['value']}"
    )


# ==========================================
# 9. SAVE EXPLANATION
# ==========================================

output_path = os.path.join(
    os.path.dirname(__file__),
    "individual_shap_explanation.csv"
)

explanation.to_csv(
    output_path,
    index=False
)

print("\n" + "=" * 60)
print("Explanation saved to:")
print(output_path)
print("=" * 60)