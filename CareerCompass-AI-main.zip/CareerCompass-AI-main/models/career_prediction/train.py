import os
import joblib
import xgboost as xgb

from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import make_scorer, f1_score

from preprocess import get_processed_data


# ==========================================
# 1. LOAD DATA
# ==========================================

X_train, X_test, y_train, y_test, label_encoder, feature_columns = (
    get_processed_data()
)

print("\nData loaded for tuning.")


# ==========================================
# 2. BASE XGBOOST MODEL
# ==========================================

model = xgb.XGBClassifier(
    objective="multi:softprob",
    num_class=len(label_encoder.classes_),
    eval_metric="mlogloss",
    random_state=42,
    n_jobs=-1
)


# ==========================================
# 3. HYPERPARAMETER SEARCH SPACE
# ==========================================

param_grid = {
    "n_estimators": [150, 200, 300, 400],
    "max_depth": [3, 4, 5, 6, 7],
    "learning_rate": [0.03, 0.05, 0.08, 0.1],
    "min_child_weight": [1, 3, 5, 7],
    "subsample": [0.7, 0.8, 0.9, 1.0],
    "colsample_bytree": [0.7, 0.8, 0.9, 1.0],
    "gamma": [0, 0.1, 0.3, 0.5]
}


# ==========================================
# 4. MACRO F1 SCORING
# ==========================================

macro_f1 = make_scorer(
    f1_score,
    average="macro"
)


# ==========================================
# 5. RANDOMIZED SEARCH
# ==========================================

search = RandomizedSearchCV(
    estimator=model,
    param_distributions=param_grid,
    n_iter=20,
    scoring=macro_f1,
    cv=3,
    verbose=2,
    random_state=42,
    n_jobs=-1
)


print("\n" + "=" * 60)
print("STARTING XGBOOST HYPERPARAMETER TUNING")
print("=" * 60)

search.fit(X_train, y_train)


# ==========================================
# 6. BEST MODEL
# ==========================================

best_model = search.best_estimator_

print("\n" + "=" * 60)
print("TUNING COMPLETED")
print("=" * 60)

print("\nBest Macro F1:")
print(f"{search.best_score_:.4f}")

print("\nBest Parameters:")

for parameter, value in search.best_params_.items():
    print(f"{parameter}: {value}")


# ==========================================
# 7. SAVE TUNED MODEL
# ==========================================

MODEL_DIR = os.path.join(
    os.path.dirname(__file__),
    "saved_model"
)

os.makedirs(MODEL_DIR, exist_ok=True)

joblib.dump(
    best_model,
    os.path.join(MODEL_DIR, "career_model_tuned.pkl")
)

joblib.dump(
    label_encoder,
    os.path.join(MODEL_DIR, "label_encoder.pkl")
)

joblib.dump(
    feature_columns.tolist(),
    os.path.join(MODEL_DIR, "feature_columns.pkl")
)

print("\nTuned model saved successfully!")

print(
    "Location:",
    os.path.join(MODEL_DIR, "career_model_tuned.pkl")
)