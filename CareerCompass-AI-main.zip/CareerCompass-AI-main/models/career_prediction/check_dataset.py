import pandas as pd

df = pd.read_csv("dataset/students.csv")

print("\n" + "=" * 60)
print("CAREER DATASET DISTRIBUTION")
print("=" * 60)

print("\nActual Career Distribution:")
print(df["actual_best_career"].value_counts())

print("\nPercentage Distribution:")
print(
    (df["actual_best_career"].value_counts(normalize=True) * 100)
    .round(2)
)

print("\n" + "=" * 60)
print("CYBERSECURITY FEATURE AVERAGES")
print("=" * 60)

cyber_features = [
    "python",
    "linux",
    "networking",
    "bash",
    "wireshark",
    "burpsuite",
    "nmap",
    "kali_linux",
    "owasp",
    "cryptography",
    "metasploit",
    "cn_score",
    "os_score",
    "ai_ml_score",
]

cyber = df[df["actual_best_career"] == "Cybersecurity Engineer"]

print(f"\nCybersecurity samples: {len(cyber)}")

for feature in cyber_features:
    print(
        f"{feature:20s}: "
        f"{cyber[feature].mean():.2f}"
    )

print("\n" + "=" * 60)
print("DATA SCIENTIST FEATURE AVERAGES")
print("=" * 60)

data_scientist = df[
    df["actual_best_career"] == "Data Scientist"
]

print(f"\nData Scientist samples: {len(data_scientist)}")

for feature in [
    "python",
    "linux",
    "networking",
    "machine_learning",
    "deep_learning",
    "tensorflow",
    "pytorch",
    "pandas",
    "numpy",
    "statistics",
    "data_visualization",
    "cn_score",
    "ai_ml_score",
]:
    print(
        f"{feature:20s}: "
        f"{data_scientist[feature].mean():.2f}"
    )