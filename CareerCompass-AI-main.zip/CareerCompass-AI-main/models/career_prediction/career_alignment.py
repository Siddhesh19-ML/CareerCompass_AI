import sys
import os

# Allow imports from this folder
sys.path.append(os.path.dirname(__file__))

from predict import predict_career
from skill_gap import calculate_skill_gap


# ==========================================
# CAREER ALIGNMENT ENGINE
# ==========================================

def career_alignment(student_profile, desired_career):

    # --------------------------------------
    # 1. ML CAREER PREDICTION
    # --------------------------------------

    prediction = predict_career(
        student_profile,
        include_explanation=True
    )

    predicted_career = prediction["best_career"]
    confidence = prediction["confidence"]


    # --------------------------------------
    # 2. SKILL GAP ANALYSIS
    # --------------------------------------

    skill_gap = calculate_skill_gap(
        student_profile,
        desired_career
    )

    skill_match = skill_gap["match_percentage"]


    # --------------------------------------
    # 3. DETERMINE ALIGNMENT
    # --------------------------------------

    if predicted_career == desired_career:

        alignment = "Strong"

        message = (
            f"Your current profile is strongly aligned "
            f"with {desired_career}."
        )

    elif skill_match >= 70:

        alignment = "Good"

        message = (
            f"Your desired career is {desired_career}, "
            f"and your current skill profile is already "
            f"fairly strong. You mainly need targeted "
            f"improvements."
        )

    elif skill_match >= 45:

        alignment = "Moderate"

        message = (
            f"You have a moderate foundation for "
            f"{desired_career}, but several important "
            f"skills still need improvement."
        )

    else:

        alignment = "Low"

        message = (
            f"Your current profile is more aligned with "
            f"{predicted_career}. However, {desired_career} "
            f"is still achievable by following a "
            f"targeted skill-development roadmap."
        )


    # --------------------------------------
    # 4. RETURN COMPLETE RESULT
    # --------------------------------------

    return {

        "predicted_career": predicted_career,

        "prediction_confidence": confidence,

        "desired_career": desired_career,

        "skill_match": skill_match,

        "alignment": alignment,

        "message": message,

        "top_careers": prediction["top_careers"],

        "explanation": prediction["explanation"],

        "strengths": skill_gap["strengths"],

        "missing_skills": skill_gap["missing_skills"]
    }


# ==========================================
# TEST
# ==========================================

if __name__ == "__main__":

    student = {

        "age": 21,
        "branch": "IT",
        "semester": 7,
        "cgpa": 8.5,
        "backlog_count": 0,

        "python": 5,
        "java": 1,
        "cpp": 2,
        "c": 1,
        "javascript": 1,
        "typescript": 0,
        "sql": 4,
        "html": 1,
        "css": 1,
        "bash": 2,

        "react": 0,
        "angular": 0,
        "vue": 0,
        "nodejs": 0,
        "express": 0,
        "django": 1,
        "flask": 2,
        "springboot": 0,

        "tensorflow": 5,
        "pytorch": 4,
        "scikit_learn": 5,
        "pandas": 5,
        "numpy": 5,
        "opencv": 3,
        "fastapi": 2,

        "docker": 1,
        "kubernetes": 0,
        "aws": 0,
        "azure": 0,
        "gcp": 0,
        "jenkins": 0,
        "github_actions": 0,
        "terraform": 0,
        "ansible": 0,

        "mysql": 3,
        "postgresql": 1,
        "mongodb": 2,
        "redis": 0,
        "firebase": 0,

        "linux": 1,
        "networking": 1,
        "wireshark": 0,
        "burpsuite": 0,
        "metasploit": 0,
        "nmap": 0,
        "kali_linux": 0,
        "owasp": 0,
        "cryptography": 1,

        "machine_learning": 5,
        "deep_learning": 4,
        "computer_vision": 3,
        "nlp": 2,
        "llm": 3,
        "data_visualization": 4,
        "statistics": 4,
        "feature_engineering": 4,
        "model_deployment": 2,

        "android": 0,
        "flutter": 0,
        "react_native": 0,
        "kotlin": 0,
        "swift": 0,

        "communication": 78,
        "leadership": 72,
        "teamwork": 82,
        "adaptability": 80,
        "presentation": 75,
        "problem_solving": 88,
        "critical_thinking": 86,

        "dsa_score": 89,
        "oop_score": 84,
        "dbms_score": 86,
        "os_score": 78,
        "cn_score": 72,
        "aptitude_score": 88,
        "webdev_score": 55,
        "ai_ml_score": 94,

        "projects": 5,
        "internships": 1,
        "hackathons": 2,
        "certifications": 3,
        "research_papers": 0,
        "open_source_contributions": 8,

        "github_repositories": 15,
        "github_stars": 30,
        "github_followers": 20,
        "github_contributions": 500,

        "leetcode_solved": 280,
        "leetcode_rating": 1750,
        "codechef_rating": 1450,
        "hackerrank_stars": 4,

        "resume_score": 82,
        "resume_projects_quality": 85,
        "resume_keywords": 35
    }


    # Student's dream career
    desired_career = "Cybersecurity Engineer"


    result = career_alignment(
        student,
        desired_career
    )


    # ======================================
    # DISPLAY RESULT
    # ======================================

    print("\n" + "=" * 60)
    print("CAREER COMPASS AI")
    print("CAREER ALIGNMENT ANALYSIS")
    print("=" * 60)

    print(
        f"\nPredicted Career : "
        f"{result['predicted_career']}"
    )

    print(
        f"Confidence       : "
        f"{result['prediction_confidence']}%"
    )

    print(
        f"\nDesired Career   : "
        f"{result['desired_career']}"
    )

    print(
        f"Skill Match      : "
        f"{result['skill_match']}%"
    )

    print(
        f"Alignment        : "
        f"{result['alignment']}"
    )

    print("\nRecommendation:")
    print(result["message"])


    print("\nTop Career Predictions:")

    for i, career in enumerate(
        result["top_careers"],
        1
    ):

        print(
            f"{i}. {career['career']} "
            f"({career['probability']}%)"
        )


    print("\nPriority Skill Gaps:")

    for skill in result["missing_skills"][:7]:

        print(
            f"✗ {skill['skill']} "
            f"({skill['current_level']}/"
            f"{skill['required_level']})"
        )