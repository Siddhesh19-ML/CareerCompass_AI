import os
import joblib
import pandas as pd
import shap


# ==========================================
# 1. LOAD MODEL
# ==========================================

BASE_DIR = os.path.dirname(__file__)
MODEL_DIR = os.path.join(BASE_DIR, "saved_model")

model = joblib.load(
    os.path.join(MODEL_DIR, "career_model.pkl")
)

label_encoder = joblib.load(
    os.path.join(MODEL_DIR, "label_encoder.pkl")
)

feature_columns = joblib.load(
    os.path.join(MODEL_DIR, "feature_columns.pkl")
)

explainer = shap.TreeExplainer(model)


# ==========================================
# 2. CAREER PREDICTION FUNCTION
# ==========================================

def predict_career(student_profile, include_explanation=True):

    # Convert profile to DataFrame
    student_df = pd.DataFrame([student_profile])

    # Encode categorical features
    categorical_columns = student_df.select_dtypes(
        include=["object"]
    ).columns

    student_df = pd.get_dummies(
        student_df,
        columns=categorical_columns,
        dtype=int
    )

    # Match training features
    student_df = student_df.reindex(
        columns=feature_columns,
        fill_value=0
    )

    # ==========================================
    # PREDICTION
    # ==========================================

    probabilities = model.predict_proba(student_df)[0]

    top_indices = probabilities.argsort()[-3:][::-1]

    top_careers = []

    for index in top_indices:

        career = label_encoder.inverse_transform(
            [index]
        )[0]

        probability = probabilities[index] * 100

        top_careers.append({
            "career": career,
            "probability": round(probability, 2)
        })

    best_index = probabilities.argmax()

    best_career = label_encoder.inverse_transform(
        [best_index]
    )[0]

    confidence = probabilities[best_index] * 100


    # ==========================================
    # RESULT
    # ==========================================

    result = {
        "best_career": best_career,
        "confidence": round(confidence, 2),
        "top_careers": top_careers
    }


    # ==========================================
    # SHAP EXPLANATION
    # ==========================================

    if include_explanation:

        shap_values = explainer.shap_values(student_df)

        if isinstance(shap_values, list):

            values = shap_values[best_index][0]

        elif shap_values.ndim == 3:

            values = shap_values[
                0, :, best_index
            ]

        else:

            values = shap_values[0]


        explanation = pd.DataFrame({
            "feature": student_df.columns,
            "value": student_df.iloc[0].values,
            "shap_value": values
        })

        # Positive factors
        positive = explanation[
            explanation["shap_value"] > 0
        ].sort_values(
            "shap_value",
            ascending=False
        ).head(5)

        # Negative factors
        negative = explanation[
            explanation["shap_value"] < 0
        ].sort_values(
            "shap_value"
        ).head(5)


        result["explanation"] = {

            "positive_factors": [
                {
                    "feature": row["feature"],
                    "value": row["value"],
                    "impact": round(row["shap_value"], 4)
                }
                for _, row in positive.iterrows()
            ],

            "negative_factors": [
                {
                    "feature": row["feature"],
                    "value": row["value"],
                    "impact": round(row["shap_value"], 4)
                }
                for _, row in negative.iterrows()
            ]
        }


    return result


# ==========================================
# 3. TEST
# ==========================================

if __name__ == "__main__":

    student = {
        "age": 21,
        "branch": "IT",
        "semester": 7,
        "cgpa": 8.5,
        "backlog_count": 0,

        "python": 5,
        "java": 1,
        "cpp": 2,
        "c": 1,
        "javascript": 1,
        "typescript": 0,
        "sql": 4,
        "html": 1,
        "css": 1,
        "php": 0,
        "bash": 2,

        "react": 0,
        "angular": 0,
        "vue": 0,
        "nodejs": 0,
        "express": 0,
        "django": 1,
        "flask": 2,
        "springboot": 0,
        "tensorflow": 5,
        "pytorch": 4,
        "scikit_learn": 5,
        "pandas": 5,
        "numpy": 5,
        "opencv": 3,
        "fastapi": 2,

        "docker": 1,
        "kubernetes": 0,
        "aws": 0,
        "azure": 0,
        "gcp": 0,
        "jenkins": 0,
        "github_actions": 0,
        "terraform": 0,
        "ansible": 0,

        "mysql": 3,
        "postgresql": 1,
        "mongodb": 2,
        "redis": 0,
        "firebase": 0,

        "linux": 2,
        "networking": 1,
        "wireshark": 0,
        "burpsuite": 0,
        "metasploit": 0,
        "nmap": 0,
        "kali_linux": 0,
        "owasp": 0,
        "cryptography": 1,

        "machine_learning": 5,
        "deep_learning": 4,
        "computer_vision": 3,
        "nlp": 2,
        "llm": 3,
        "data_visualization": 4,
        "statistics": 4,
        "feature_engineering": 4,
        "model_deployment": 2,

        "android": 0,
        "flutter": 0,
        "react_native": 0,
        "kotlin": 0,
        "swift": 0,

        "communication": 78,
        "leadership": 72,
        "teamwork": 82,
        "adaptability": 80,
        "presentation": 75,
        "problem_solving": 88,
        "critical_thinking": 86,

        "dsa_score": 89,
        "oop_score": 84,
        "dbms_score": 86,
        "os_score": 78,
        "cn_score": 72,
        "aptitude_score": 88,
        "webdev_score": 55,
        "ai_ml_score": 94,

        "projects": 5,
        "internships": 1,
        "hackathons": 2,
        "certifications": 3,
        "research_papers": 0,
        "open_source_contributions": 8,

        "github_repositories": 15,
        "github_stars": 30,
        "github_followers": 20,
        "github_contributions": 500,

        "leetcode_solved": 280,
        "leetcode_rating": 1750,
        "codechef_rating": 1450,
        "hackerrank_stars": 4,

        "resume_score": 82,
        "resume_projects_quality": 85,
        "resume_keywords": 35
    }

    result = predict_career(student)

    print("\n" + "=" * 60)
    print("CAREER COMPASS AI")
    print("=" * 60)

    print(
        f"\nBest Career: "
        f"{result['best_career']}"
    )

    print(
        f"Confidence: "
        f"{result['confidence']}%"
    )

    print("\nTop Careers:")

    for i, career in enumerate(
        result["top_careers"], 1
    ):
        print(
            f"{i}. {career['career']} "
            f"({career['probability']}%)"
        )


    print("\nPositive Factors:")

    for factor in result[
        "explanation"
    ]["positive_factors"]:

        print(
            f"+ {factor['feature']} "
            f"(impact: {factor['impact']})"
        )


    print("\nNegative Factors:")

    for factor in result[
        "explanation"
    ]["negative_factors"]:

        print(
            f"- {factor['feature']} "
            f"(impact: {factor['impact']})"
        )