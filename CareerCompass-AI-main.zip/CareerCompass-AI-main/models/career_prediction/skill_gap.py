import pandas as pd


# ==========================================
# CAREER SKILL REQUIREMENTS
# ==========================================

CAREER_REQUIREMENTS = {

    "AI Engineer": {
        "python": 5,
        "machine_learning": 5,
        "deep_learning": 4,
        "tensorflow": 4,
        "pytorch": 4,
        "scikit_learn": 4,
        "numpy": 4,
        "pandas": 4,
        "statistics": 4,
        "sql": 3,
        "git": 3,
        "docker": 3,
        "model_deployment": 3
    },

    "Data Scientist": {
        "python": 5,
        "machine_learning": 5,
        "pandas": 5,
        "numpy": 5,
        "statistics": 5,
        "scikit_learn": 4,
        "sql": 4,
        "data_visualization": 4,
        "feature_engineering": 4
    },

    "Data Analyst": {
        "python": 4,
        "sql": 5,
        "pandas": 4,
        "statistics": 4,
        "data_visualization": 5,
        "excel": 4,
        "powerbi": 4,
        "tableau": 3
    },

    "Cybersecurity Engineer": {
        "python": 4,
        "linux": 5,
        "networking": 5,
        "bash": 4,
        "nmap": 4,
        "wireshark": 4,
        "burpsuite": 4,
        "owasp": 4,
        "cryptography": 3,
        "kali_linux": 4
    },

    "Frontend Developer": {
        "html": 5,
        "css": 5,
        "javascript": 5,
        "typescript": 4,
        "react": 4,
        "git": 3
    },

    "Backend Developer": {
        "java": 4,
        "python": 4,
        "sql": 5,
        "nodejs": 4,
        "express": 4,
        "springboot": 4,
        "mongodb": 3,
        "git": 3
    },

    "Full Stack Developer": {
        "html": 5,
        "css": 5,
        "javascript": 5,
        "typescript": 4,
        "react": 4,
        "nodejs": 4,
        "express": 4,
        "sql": 4,
        "mongodb": 4,
        "git": 3
    },

    "Cloud Engineer": {
        "linux": 5,
        "docker": 5,
        "kubernetes": 4,
        "aws": 4,
        "azure": 3,
        "gcp": 3,
        "terraform": 4,
        "networking": 4,
        "git": 3
    },

    "DevOps Engineer": {
        "linux": 5,
        "bash": 4,
        "docker": 5,
        "kubernetes": 5,
        "jenkins": 4,
        "github_actions": 4,
        "terraform": 4,
        "ansible": 3,
        "git": 4
    },

    "Mobile App Developer": {
        "android": 5,
        "kotlin": 4,
        "java": 4,
        "flutter": 4,
        "react_native": 3,
        "git": 3
    },

    "Software Engineer": {
        "python": 4,
        "java": 4,
        "cpp": 4,
        "sql": 4,
        "dsa_score": 85,
        "oop_score": 85,
        "git": 3
    },

    "Business Analyst": {
        "sql": 4,
        "statistics": 4,
        "data_visualization": 4,
        "communication": 85,
        "critical_thinking": 85,
        "aptitude_score": 85
    }
}


# ==========================================
# SKILL GAP FUNCTION
# ==========================================

def calculate_skill_gap(student_profile, desired_career):

    if desired_career not in CAREER_REQUIREMENTS:
        raise ValueError(
            f"Unknown career: {desired_career}"
        )

    requirements = CAREER_REQUIREMENTS[
        desired_career
    ]

    strengths = []
    gaps = []

    total_score = 0
    max_score = 0

    for skill, required_level in requirements.items():

        current_level = student_profile.get(
            skill,
            0
        )

        # Convert assessment scores from 0-100
        # into a 0-5 scale.
        if skill.endswith("_score") or skill in [
            "communication",
            "critical_thinking"
        ]:
            current_level = (
                float(current_level) / 20
            )

        current_level = min(
            float(current_level),
            5
        )

        contribution = min(
            current_level / required_level,
            1
        )

        total_score += contribution
        max_score += 1

        if current_level >= required_level:

            strengths.append({
                "skill": skill,
                "current_level": round(
                    current_level, 2
                ),
                "required_level": required_level
            })

        else:

            gap = required_level - current_level

            gaps.append({
                "skill": skill,
                "current_level": round(
                    current_level, 2
                ),
                "required_level": required_level,
                "gap": round(gap, 2)
            })

    match_percentage = (
        total_score / max_score
    ) * 100

    # Largest gaps first
    gaps.sort(
        key=lambda x: x["gap"],
        reverse=True
    )

    return {
        "career": desired_career,
        "match_percentage": round(
            match_percentage, 2
        ),
        "strengths": strengths,
        "missing_skills": gaps
    }


# ==========================================
# TEST
# ==========================================

if __name__ == "__main__":

    student = {

        "python": 5,
        "machine_learning": 5,
        "deep_learning": 4,
        "tensorflow": 5,
        "pytorch": 4,
        "scikit_learn": 5,
        "numpy": 5,
        "pandas": 5,
        "statistics": 4,
        "sql": 3,

        "linux": 1,
        "networking": 1,
        "bash": 2,
        "nmap": 0,
        "wireshark": 0,
        "burpsuite": 0,
        "owasp": 0,
        "cryptography": 1,
        "kali_linux": 0
    }

    desired_career = "Cybersecurity Engineer"

    result = calculate_skill_gap(
        student,
        desired_career
    )

    print("\n" + "=" * 60)
    print("CAREER COMPASS AI - SKILL GAP ANALYSIS")
    print("=" * 60)

    print(
        f"\nDesired Career: "
        f"{result['career']}"
    )

    print(
        f"Current Match: "
        f"{result['match_percentage']}%"
    )

    print("\nStrengths:")

    for skill in result["strengths"]:

        print(
            f"✓ {skill['skill']}"
            f" ({skill['current_level']}/"
            f"{skill['required_level']})"
        )

    print("\nMissing / Weak Skills:")

    for skill in result["missing_skills"]:

        print(
            f"✗ {skill['skill']}"
            f" ({skill['current_level']}/"
            f"{skill['required_level']})"
        )