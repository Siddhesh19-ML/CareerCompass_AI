from skill_gap import calculate_skill_gap


# ==========================================
# LEARNING ROADMAP DATABASE
# ==========================================

SKILL_RESOURCES = {

    "linux": {
        "title": "Linux Fundamentals",
        "duration": "2 weeks",
        "prerequisite": None
    },

    "networking": {
        "title": "Computer Networking",
        "duration": "2 weeks",
        "prerequisite": None
    },

    "bash": {
        "title": "Bash Scripting",
        "duration": "1 week",
        "prerequisite": "linux"
    },

    "nmap": {
        "title": "Nmap & Network Scanning",
        "duration": "1 week",
        "prerequisite": "networking"
    },

    "wireshark": {
        "title": "Wireshark & Network Analysis",
        "duration": "1 week",
        "prerequisite": "networking"
    },

    "burpsuite": {
        "title": "Burp Suite",
        "duration": "1 week",
        "prerequisite": "networking"
    },

    "owasp": {
        "title": "OWASP Top 10 & Web Security",
        "duration": "2 weeks",
        "prerequisite": "networking"
    },

    "kali_linux": {
        "title": "Kali Linux",
        "duration": "1 week",
        "prerequisite": "linux"
    },

    "cryptography": {
        "title": "Cryptography Fundamentals",
        "duration": "1 week",
        "prerequisite": "networking"
    },

    "python": {
        "title": "Python Programming",
        "duration": "2 weeks",
        "prerequisite": None
    },

    "machine_learning": {
        "title": "Machine Learning Fundamentals",
        "duration": "3 weeks",
        "prerequisite": "python"
    },

    "deep_learning": {
        "title": "Deep Learning",
        "duration": "3 weeks",
        "prerequisite": "machine_learning"
    },

    "tensorflow": {
        "title": "TensorFlow",
        "duration": "2 weeks",
        "prerequisite": "deep_learning"
    },

    "pytorch": {
        "title": "PyTorch",
        "duration": "2 weeks",
        "prerequisite": "deep_learning"
    },

    "docker": {
        "title": "Docker & Containerization",
        "duration": "2 weeks",
        "prerequisite": "linux"
    },

    "kubernetes": {
        "title": "Kubernetes",
        "duration": "3 weeks",
        "prerequisite": "docker"
    },

    "aws": {
        "title": "AWS Cloud Fundamentals",
        "duration": "3 weeks",
        "prerequisite": "linux"
    },

    "terraform": {
        "title": "Terraform & Infrastructure as Code",
        "duration": "2 weeks",
        "prerequisite": "aws"
    },

    "javascript": {
        "title": "JavaScript",
        "duration": "3 weeks",
        "prerequisite": None
    },

    "react": {
        "title": "React.js",
        "duration": "3 weeks",
        "prerequisite": "javascript"
    },

    "sql": {
        "title": "SQL & Database Fundamentals",
        "duration": "2 weeks",
        "prerequisite": None
    },

    "data_visualization": {
        "title": "Data Visualization",
        "duration": "2 weeks",
        "prerequisite": "pandas"
    },

    "statistics": {
        "title": "Statistics for Data Science",
        "duration": "3 weeks",
        "prerequisite": None
    },

    "pandas": {
        "title": "Pandas for Data Analysis",
        "duration": "2 weeks",
        "prerequisite": "python"
    },

    "numpy": {
        "title": "NumPy",
        "duration": "1 week",
        "prerequisite": "python"
    }
}


# ==========================================
# ROADMAP GENERATOR
# ==========================================

def generate_roadmap(
    student_profile,
    desired_career,
    months=4
):

    # Get skill gaps
    gap_result = calculate_skill_gap(
        student_profile,
        desired_career
    )

    missing_skills = gap_result["missing_skills"]

    # --------------------------------------
    # Sort by largest gap
    # --------------------------------------

    missing_skills = sorted(
        missing_skills,
        key=lambda x: x["gap"],
        reverse=True
    )

    # --------------------------------------
    # Select relevant skills
    # --------------------------------------

    selected = []

    for skill in missing_skills:

        skill_name = skill["skill"]

        if skill_name in SKILL_RESOURCES:

            selected.append(skill_name)

    # Maximum 3 skills per month
    max_skills = months * 3

    selected = selected[:max_skills]

    # --------------------------------------
    # Build monthly roadmap
    # --------------------------------------

    roadmap = []

    for month in range(1, months + 1):

        start = (month - 1) * 3
        end = month * 3

        month_skills = selected[start:end]

        if not month_skills:
            break

        topics = []

        for skill in month_skills:

            resource = SKILL_RESOURCES[skill]

            topics.append({
                "skill": skill,
                "title": resource["title"],
                "duration": resource["duration"],
                "prerequisite": resource["prerequisite"]
            })

        roadmap.append({
            "month": month,
            "topics": topics
        })

    # --------------------------------------
    # Estimate target match
    # --------------------------------------

    current_match = gap_result["match_percentage"]

    improvement_per_skill = (
        (100 - current_match) /
        max(len(selected), 1)
    )

    target_match = min(
        95,
        current_match +
        improvement_per_skill * len(selected)
    )

    return {
        "career": desired_career,
        "current_match": current_match,
        "target_match": round(target_match, 2),
        "total_skills": len(selected),
        "roadmap": roadmap
    }


# ==========================================
# TEST
# ==========================================

if __name__ == "__main__":

    student = {

        "python": 5,

        "linux": 1,
        "networking": 1,
        "bash": 2,

        "nmap": 0,
        "wireshark": 0,
        "burpsuite": 0,
        "owasp": 0,
        "kali_linux": 0,
        "cryptography": 1,

        "machine_learning": 5,
        "deep_learning": 4,
        "tensorflow": 5,
        "pytorch": 4,

        "sql": 3
    }

    desired_career = "Cybersecurity Engineer"

    result = generate_roadmap(
        student,
        desired_career,
        months=4
    )

    print("\n" + "=" * 60)
    print("CAREER COMPASS AI")
    print("PERSONALIZED ROADMAP")
    print("=" * 60)

    print(
        f"\nCareer: {result['career']}"
    )

    print(
        f"Current Match: "
        f"{result['current_match']}%"
    )

    print(
        f"Target Match: "
        f"{result['target_match']}%"
    )

    print(
        f"\nSkills to Develop: "
        f"{result['total_skills']}"
    )

    for month in result["roadmap"]:

        print(
            f"\nMONTH {month['month']}"
        )

        print("-" * 40)

        for topic in month["topics"]:

            print(
                f"• {topic['title']}"
            )

            print(
                f"  Duration: "
                f"{topic['duration']}"
            )

            if topic["prerequisite"]:

                print(
                    f"  Prerequisite: "
                    f"{topic['prerequisite']}"
                )