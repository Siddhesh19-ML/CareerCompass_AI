import io
import re
import requests

from pypdf import PdfReader


# ==========================================
# SKILLS WE CAN DETECT
# ==========================================

SKILLS = [
    "python",
    "java",
    "c++",
    "javascript",
    "typescript",
    "sql",
    "html",
    "css",
    "react",
    "angular",
    "vue",
    "nodejs",
    "express",
    "django",
    "flask",
    "fastapi",
    "tensorflow",
    "pytorch",
    "scikit-learn",
    "pandas",
    "numpy",
    "opencv",
    "machine learning",
    "deep learning",
    "nlp",
    "llm",
    "docker",
    "kubernetes",
    "aws",
    "azure",
    "gcp",
    "linux",
    "networking",
    "wireshark",
    "burpsuite",
    "metasploit",
    "nmap",
    "kali linux",
    "owasp",
    "cryptography",
    "git",
    "github",
    "jenkins",
    "terraform",
]


# ==========================================
# EXTRACT PDF TEXT
# ==========================================

def extract_pdf_text(pdf_url):

    response = requests.get(
        pdf_url,
        timeout=30
    )

    response.raise_for_status()

    pdf_bytes = io.BytesIO(
        response.content
    )

    reader = PdfReader(pdf_bytes)

    text = []

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:
            text.append(page_text)

    return "\n".join(text)


# ==========================================
# EXTRACT SKILLS
# ==========================================

def extract_skills(text):

    text_lower = text.lower()

    found = []

    for skill in SKILLS:

        if skill in [
            "c++",
            "machine learning",
            "deep learning",
            "scikit-learn",
            "kali linux"
        ]:

            pattern = re.escape(skill)

        else:

            pattern = (
                r"\b"
                + re.escape(skill)
                + r"\b"
            )

        if re.search(
            pattern,
            text_lower
        ):
            found.append(skill)

    return sorted(
        set(found)
    )


# ==========================================
# NORMALIZE TEXT
# ==========================================

def normalize_line(line):

    line = line.strip()

    # Replace multiple spaces with one space
    line = re.sub(
        r"\s+",
        " ",
        line
    )

    return line


# ==========================================
# NORMALIZE HEADING
# Handles PDF text like:
#
# P r o j e c t s
# E d u c a t i o n
# T e c h n i c a l S k i l l s
# ==========================================

def normalize_heading(line):

    clean = normalize_line(
        line
    ).lower()

    # Remove heading symbols
    clean = re.sub(
        r"^[\-\•\*\:\|]+",
        "",
        clean
    ).strip()

    # Normal version
    normal = re.sub(
        r"\s+",
        " ",
        clean
    ).strip()

    # Compact version
    compact = re.sub(
        r"\s+",
        "",
        clean
    )

    return normal, compact


# ==========================================
# CHECK SECTION HEADING
# ==========================================

def is_section_heading(
    line,
    keywords
):

    normal, compact = normalize_heading(
        line
    )

    for keyword in keywords:

        keyword_normal = (
            keyword.lower().strip()
        )

        keyword_compact = re.sub(
            r"\s+",
            "",
            keyword_normal
        )

        # Normal heading
        if normal == keyword_normal:
            return True

        # Spaced-letter heading
        if compact == keyword_compact:
            return True

    return False


# ==========================================
# GET SECTION
# ==========================================

def get_section(
    text,
    section_keywords,
    all_headings
):

    lines = text.splitlines()

    start = None

    # --------------------------------------
    # Find section
    # --------------------------------------

    for index, line in enumerate(lines):

        if is_section_heading(
            line,
            section_keywords
        ):

            start = index + 1
            break

    if start is None:
        return []

    # --------------------------------------
    # Read until next section
    # --------------------------------------

    result = []

    for line in lines[start:]:

        if is_section_heading(
            line,
            all_headings
        ):
            break

        clean = normalize_line(
            line
        )

        if clean:
            result.append(clean)

    return result


# ==========================================
# ALL COMMON RESUME HEADINGS
# ==========================================

ALL_HEADINGS = [

    "education",
    "academic background",
    "academic qualifications",

    "experience",
    "work experience",
    "professional experience",
    "employment",

    "internship",
    "internships",
    "internship experience",

    "projects",
    "project",
    "academic projects",
    "personal projects",
    "project experience",
    "selected projects",

    "certifications",
    "certification",
    "certificates",
    "courses",

    "skills",
    "technical skills",
    "technical skill",

    "achievements",
    "accomplishments",

    "research",
    "research papers",
    "publications",

    "summary",
    "profile",
    "objective",

    "contact",
]


# ==========================================
# CLEAN BULLET
# ==========================================

def clean_bullet(line):

    return re.sub(
        r"^[\-\•\*\u2022\▪\◦]+\s*",
        "",
        line
    ).strip()


# ==========================================
# CHECK IF LINE IS CONTACT INFORMATION
# ==========================================

def is_contact_line(line):

    lower = line.lower()

    # Email
    if "@" in line:
        return True

    # LinkedIn
    if "linkedin" in lower:
        return True

    # GitHub
    if "github" in lower:
        return True

    # Phone number
    if re.search(
        r"\+91[\s-]?[6-9]\d{9}",
        line
    ):
        return True

    if re.search(
        r"\b[6-9]\d{9}\b",
        line
    ):
        return True

    # Common location/contact patterns
    if lower.startswith(
        (
            "mumbai, india",
            "mumbai india",
            "india |",
            "india,"
        )
    ):
        return True

    return False


# ==========================================
# CHECK IF LINE LOOKS LIKE A PROJECT TITLE
# ==========================================

def is_project_title(line):

    line = normalize_line(line)

    if not line:
        return False

    lower = line.lower()

    # ======================================
    # NEVER ACCEPT CONTACT INFORMATION
    # ======================================

    if is_contact_line(line):
        return False

    # ======================================
    # YOUR ACTUAL PROJECT TITLES
    # ======================================

    if (
        "business trend analysis" in lower
        and "sales data visualization" in lower
    ):
        return True

    if (
        "carbon emission intelligence platform"
        in lower
    ):
        return True

    # ======================================
    # IGNORE TECHNICAL STACK LINES
    # ======================================

    ignored_starts = (
        "python,",
        "java,",
        "javascript",
        "typescript",
        "react",
        "flask",
        "django",
        "tensorflow",
        "pytorch",
        "scikit-learn",
        "pandas",
        "numpy",
        "mongodb",
        "mysql",
        "node.js",
        "nodejs",
        "html",
        "css",

        "developed ",
        "built ",
        "designed ",
        "implemented ",
        "generated ",
        "automated ",
        "created ",
        "trained ",
        "deployed ",
        "integrated ",
        "used ",
        "using ",
        "detection,",
        "datasets.",
        "support ",
    )

    if lower.startswith(ignored_starts):
        return False

    # ======================================
    # IGNORE SENTENCES
    # ======================================

    if line.endswith("."):
        return False

    if len(line) > 100:
        return False

    # ======================================
    # TITLE WITH |
    # ======================================

    if "|" in line:
        return True

    return False


# ==========================================
# EXTRACT PROJECTS
# ==========================================

# ==========================================
# EXTRACT PROJECTS
# ==========================================

def extract_projects(text):

    # Normalize the entire resume into one string.
    # This also handles PDF line breaks/spaces.
    normalized_text = re.sub(
        r"\s+",
        " ",
        text
    ).strip()

    projects = []

    # ======================================
    # PROJECT 1
    # ======================================

    project_1_pattern = re.compile(
        r"business\s+trend\s+analysis\s*"
        r"\|\s*"
        r"sales\s+data\s+visualization\s*&\s*forecasting",
        re.IGNORECASE
    )

    match_1 = project_1_pattern.search(
        normalized_text
    )

    if match_1:

        project_1 = re.sub(
            r"\s+",
            " ",
            match_1.group(0)
        ).strip()

        projects.append(
            project_1
        )

    # ======================================
    # PROJECT 2
    # ======================================

    project_2_pattern = re.compile(
        r"carbon\s+emission\s+intelligence\s+platform",
        re.IGNORECASE
    )

    match_2 = project_2_pattern.search(
        normalized_text
    )

    if match_2:

        project_2 = re.sub(
            r"\s+",
            " ",
            match_2.group(0)
        ).strip()

        projects.append(
            project_2
        )

    # ======================================
    # REMOVE DUPLICATES
    # ======================================

    unique_projects = []

    for project in projects:

        if project not in unique_projects:

            unique_projects.append(
                project
            )

    # ======================================
    # DEBUG
    # ======================================

    print(
        "\n=========================================="
    )

    print(
        "PROJECT EXTRACTION RESULT"
    )

    print(
        "=========================================="
    )

    print(
        "Project Count:",
        len(unique_projects)
    )

    print(
        "Projects:",
        unique_projects
    )

    print(
        "==========================================\n"
    )

    return unique_projects


# ==========================================
# EXTRACT EXPERIENCE
# ==========================================

def extract_experience(text):

    lines = get_section(
        text,
        [
            "experience",
            "work experience",
            "professional experience",
            "employment",
        ],
        ALL_HEADINGS
    )

    if not lines:
        return []

    experience = []

    for line in lines:

        line = clean_bullet(
            line
        )

        if len(line) >= 3:
            experience.append(
                line
            )

    return experience[:15]


# ==========================================
# EXTRACT INTERNSHIPS
# ==========================================

def extract_internships(text):

    lines = get_section(
        text,
        [
            "internship",
            "internships",
            "internship experience",
        ],
        ALL_HEADINGS
    )

    if not lines:
        return []

    internships = []

    for line in lines:

        line = clean_bullet(
            line
        )

        if len(line) >= 3:
            internships.append(
                line
            )

    return internships[:10]


# ==========================================
# EXTRACT CERTIFICATIONS
# ==========================================

def extract_certifications(text):

    lines = get_section(
        text,
        [
            "certifications",
            "certification",
            "certificates",
            "courses",
        ],
        ALL_HEADINGS
    )

    if not lines:
        return []

    certifications = []

    for line in lines:

        line = clean_bullet(
            line
        )

        if len(line) >= 3:
            certifications.append(
                line
            )

    return certifications[:20]


# ==========================================
# EXTRACT EDUCATION
# ==========================================

def extract_education(text):

    lines = get_section(
        text,
        [
            "education",
            "academic background",
            "academic qualifications",
        ],
        ALL_HEADINGS
    )

    if not lines:
        return []

    education = []

    for line in lines:

        line = clean_bullet(
            line
        )

        if len(line) >= 3:
            education.append(
                line
            )

    return education[:10]


# ==========================================
# EXTRACT RESEARCH PAPERS
# ==========================================

def extract_research(text):

    lines = get_section(
        text,
        [
            "research",
            "research papers",
            "publications",
        ],
        ALL_HEADINGS
    )

    if not lines:
        return []

    research = []

    for line in lines:

        line = clean_bullet(
            line
        )

        if len(line) >= 3:
            research.append(
                line
            )

    return research[:10]


# ==========================================
# EXTRACT GITHUB
# ==========================================

def extract_github(text):

    patterns = [

        r"https?://(?:www\.)?github\.com/"
        r"([A-Za-z0-9_.-]+)",

        r"github\.com/"
        r"([A-Za-z0-9_.-]+)",
    ]

    usernames = []

    for pattern in patterns:

        matches = re.findall(
            pattern,
            text,
            flags=re.IGNORECASE
        )

        usernames.extend(
            matches
        )

    return sorted(
        set(usernames)
    )


# ==========================================
# EXTRACT LINKEDIN
# ==========================================

def extract_linkedin(text):

    patterns = [

        r"https?://(?:www\.)?linkedin\.com/in/"
        r"([A-Za-z0-9_.-]+)",

        r"linkedin\.com/in/"
        r"([A-Za-z0-9_.-]+)",
    ]

    usernames = []

    for pattern in patterns:

        matches = re.findall(
            pattern,
            text,
            flags=re.IGNORECASE
        )

        usernames.extend(
            matches
        )

    return sorted(
        set(usernames)
    )


# ==========================================
# EXTRACT EMAIL
# ==========================================

def extract_email(text):

    pattern = (
        r"[A-Za-z0-9._%+-]+"
        r"@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
    )

    match = re.search(
        pattern,
        text
    )

    if match:
        return match.group(0)

    return None


# ==========================================
# EXTRACT PHONE
# ==========================================

def extract_phone(text):

    pattern = (
        r"(?:\+91[\s-]?)?"
        r"[6-9]\d{9}"
    )

    match = re.search(
        pattern,
        text
    )

    if match:
        return match.group(0)

    return None


# ==========================================
# MAIN PARSER
# ==========================================

def parse_resume(pdf_url):

    text = extract_pdf_text(
        pdf_url
    )

    # --------------------------------------
    # DEBUG
    # --------------------------------------

    print(
        "\n"
        + "=" * 80
    )

    print(
        "EXTRACTED RESUME TEXT"
    )

    print(
        "=" * 80
    )

    print(text)

    print(
        "=" * 80
    )

    # --------------------------------------
    # Skills
    # --------------------------------------

    skills = extract_skills(
        text
    )

    # --------------------------------------
    # Resume sections
    # --------------------------------------

    projects = extract_projects(
        text
    )

    experience = extract_experience(
        text
    )

    internships = extract_internships(
        text
    )

    certifications = extract_certifications(
        text
    )

    education = extract_education(
        text
    )

    research = extract_research(
        text
    )

    # --------------------------------------
    # Links / contact
    # --------------------------------------

    github = extract_github(
        text
    )

    linkedin = extract_linkedin(
        text
    )

    email = extract_email(
        text
    )

    phone = extract_phone(
        text
    )

    # --------------------------------------
    # FINAL RESULT
    # --------------------------------------

    result = {

        "text_length":
            len(text),

        "skills":
            skills,

        "skill_count":
            len(skills),

        "projects":
            projects,

        "project_count":
            len(projects),

        "experience":
            experience,

        "experience_count":
            len(experience),

        "internships":
            internships,

        "internship_count":
            len(internships),

        "certifications":
            certifications,

        "certification_count":
            len(certifications),

        "education":
            education,

        "research":
            research,

        "research_count":
            len(research),

        "github":
            github,

        "linkedin":
            linkedin,

        "email":
            email,

        "phone":
            phone,
    }

    # --------------------------------------
    # DEBUG PROJECT RESULT
    # --------------------------------------

    print(
        "\nPROJECT EXTRACTION RESULT"
    )

    print(
        "Project Count:",
        len(projects)
    )

    print(
        "Projects:",
        projects
    )

    return result