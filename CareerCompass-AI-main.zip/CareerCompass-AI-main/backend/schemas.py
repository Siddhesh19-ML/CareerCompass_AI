from pydantic import BaseModel, Field
from typing import Optional


class StudentProfile(BaseModel):

    age: int = Field(ge=16, le=40)
    branch: str
    semester: int = Field(ge=1, le=12)
    cgpa: float = Field(ge=0, le=10)
    backlog_count: int = Field(ge=0)

    # Programming
    python: float = Field(0, ge=0, le=5)
    java: float = Field(0, ge=0, le=5)
    cpp: float = Field(0, ge=0, le=5)
    javascript: float = Field(0, ge=0, le=5)
    typescript: float = Field(0, ge=0, le=5)
    sql: float = Field(0, ge=0, le=5)

    # AI / ML
    tensorflow: float = Field(0, ge=0, le=5)
    pytorch: float = Field(0, ge=0, le=5)
    scikit_learn: float = Field(0, ge=0, le=5)
    pandas: float = Field(0, ge=0, le=5)
    numpy: float = Field(0, ge=0, le=5)
    machine_learning: float = Field(0, ge=0, le=5)
    deep_learning: float = Field(0, ge=0, le=5)

    # Cybersecurity
    linux: float = Field(0, ge=0, le=5)
    networking: float = Field(0, ge=0, le=5)
    bash: float = Field(0, ge=0, le=5)
    nmap: float = Field(0, ge=0, le=5)
    wireshark: float = Field(0, ge=0, le=5)
    burpsuite: float = Field(0, ge=0, le=5)
    kali_linux: float = Field(0, ge=0, le=5)
    owasp: float = Field(0, ge=0, le=5)
    cryptography: float = Field(0, ge=0, le=5)

    # Soft skills
    communication: float = Field(0, ge=0, le=100)
    leadership: float = Field(0, ge=0, le=100)
    teamwork: float = Field(0, ge=0, le=100)
    problem_solving: float = Field(0, ge=0, le=100)
    critical_thinking: float = Field(0, ge=0, le=100)

    # Assessment scores
    dsa_score: float = Field(0, ge=0, le=100)
    oop_score: float = Field(0, ge=0, le=100)
    dbms_score: float = Field(0, ge=0, le=100)
    os_score: float = Field(0, ge=0, le=100)
    cn_score: float = Field(0, ge=0, le=100)
    aptitude_score: float = Field(0, ge=0, le=100)
    webdev_score: float = Field(0, ge=0, le=100)
    ai_ml_score: float = Field(0, ge=0, le=100)

    # Experience
    projects: int = Field(0, ge=0)
    internships: int = Field(0, ge=0)
    hackathons: int = Field(0, ge=0)
    certifications: int = Field(0, ge=0)

    # GitHub
    github_repositories: int = Field(0, ge=0)
    github_stars: int = Field(0, ge=0)
    github_followers: int = Field(0, ge=0)
    github_contributions: int = Field(0, ge=0)

    # Coding platforms
    leetcode_solved: int = Field(0, ge=0)
    leetcode_rating: int = Field(0, ge=0)

    # Resume
    resume_score: float = Field(0, ge=0, le=100)
    resume_projects_quality: float = Field(0, ge=0, le=100)
    resume_keywords: int = Field(0, ge=0)


class CareerAnalysisRequest(BaseModel):

    student_profile: StudentProfile

    desired_career: str