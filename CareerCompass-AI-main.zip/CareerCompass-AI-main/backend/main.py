import sys
import os

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.schemas import CareerAnalysisRequest
from backend.resume_parser import parse_resume


# ==========================================
# ADD PROJECT ROOT / ML MODEL PATH
# ==========================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ML_DIR = os.path.join(
    BASE_DIR,
    "models",
    "career_prediction"
)

sys.path.insert(0, ML_DIR)


# ==========================================
# IMPORT ML MODULES
# ==========================================

from predict import predict_career
from skill_gap import calculate_skill_gap
from roadmap import generate_roadmap


# ==========================================
# RESUME REQUEST SCHEMA
# ==========================================

class ResumeParseRequest(BaseModel):
    resume_url: str


# ==========================================
# CREATE FASTAPI APP
# ==========================================

app = FastAPI(
    title="CareerCompass AI",
    description="AI-powered Career Intelligence Platform",
    version="1.0.0"
)


# ==========================================
# CORS
# ==========================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",

        "http://localhost:5174",
        "http://127.0.0.1:5174",

        "http://localhost:5175",
        "http://127.0.0.1:5175",

        "http://localhost:5176",
        "http://127.0.0.1:5176",
    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


# ==========================================
# ROOT ENDPOINT
# ==========================================

@app.get("/")
def root():

    return {
        "message": "CareerCompass AI API is running",
        "status": "success"
    }


# ==========================================
# RESUME PARSING
# ==========================================

@app.post("/resume-parse")
def resume_parse(
    request: ResumeParseRequest
):

    try:

        # ----------------------------------
        # Parse uploaded resume
        # ----------------------------------

        result = parse_resume(
            request.resume_url
        )

        # ----------------------------------
        # Return extracted information
        # ----------------------------------

        return {

            "status": "success",

            "result": result

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ==========================================
# CAREER ANALYSIS
# ==========================================

@app.post("/career-analysis")
def career_analysis(
    request: CareerAnalysisRequest
):

    try:

        # ----------------------------------
        # Convert profile to dictionary
        # ----------------------------------

        student = (
            request.student_profile.model_dump()
        )

        desired_career = (
            request.desired_career
        )


        # ==================================
        # 1. CAREER PREDICTION
        # ==================================

        prediction = predict_career(
            student,
            include_explanation=True
        )


        # ==================================
        # 2. SKILL GAP
        # ==================================

        skill_gap = calculate_skill_gap(
            student,
            desired_career
        )


        # ==================================
        # 3. CAREER ALIGNMENT
        # ==================================

        predicted_career = prediction[
            "best_career"
        ]

        confidence = prediction[
            "confidence"
        ]

        skill_match = skill_gap[
            "match_percentage"
        ]


        # ----------------------------------
        # Determine alignment
        # ----------------------------------

        if predicted_career == desired_career:

            alignment = "Strong"

            message = (
                f"Your current profile is strongly "
                f"aligned with {desired_career}."
            )

        elif skill_match >= 70:

            alignment = "Good"

            message = (
                f"You already have a strong foundation "
                f"for {desired_career}."
            )

        elif skill_match >= 45:

            alignment = "Moderate"

            message = (
                f"You have a moderate foundation for "
                f"{desired_career}, but several skills "
                f"need improvement."
            )

        else:

            alignment = "Low"

            message = (
                f"Your current profile is more aligned "
                f"with {predicted_career}. However, "
                f"{desired_career} is achievable through "
                f"a targeted roadmap."
            )


        # ==================================
        # 4. PERSONALIZED ROADMAP
        # ==================================

        roadmap = generate_roadmap(
            student,
            desired_career,
            months=4
        )


        # ==================================
        # 5. FINAL RESPONSE
        # ==================================

        return {

            "status": "success",

            # ------------------------------
            # Career prediction
            # ------------------------------

            "prediction": {

                "best_career":
                    predicted_career,

                "confidence":
                    confidence,

                "top_careers":
                    prediction[
                        "top_careers"
                    ]
            },

            # ------------------------------
            # Desired career
            # ------------------------------

            "desired_career":
                desired_career,

            # ------------------------------
            # Career alignment
            # ------------------------------

            "alignment": {

                "level":
                    alignment,

                "skill_match":
                    skill_match,

                "message":
                    message
            },

            # ------------------------------
            # Skill gap
            # ------------------------------

            "skill_gap": {

                "strengths":
                    skill_gap[
                        "strengths"
                    ],

                "missing_skills":
                    skill_gap[
                        "missing_skills"
                    ]
            },

            # ------------------------------
            # Model explanation
            # ------------------------------

            "explanation":
                prediction[
                    "explanation"
                ],

            # ------------------------------
            # Learning roadmap
            # ------------------------------

            "roadmap":
                roadmap[
                    "roadmap"
                ]
        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )