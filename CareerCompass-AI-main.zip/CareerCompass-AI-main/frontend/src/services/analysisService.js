import { supabase } from "../lib/supabase";
import { analyzeCareer as analyzeCareerAPI } from "./api";

// ==========================================
// RUN CAREER ANALYSIS
// ==========================================

export async function analyzeCareer(
  studentProfile,
  desiredCareer
) {
  return await analyzeCareerAPI(
    studentProfile,
    desiredCareer
  );
}

// ==========================================
// SAVE CAREER ANALYSIS
// ==========================================

export async function saveCareerAnalysis(result) {
  // ------------------------------------------
  // Get authenticated user
  // ------------------------------------------

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  // ------------------------------------------
  // Verify student profile exists
  // ------------------------------------------

  const {
    data: profile,
    error: profileError,
  } = await supabase
    .from("student_profiles")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (profileError) {
    throw profileError;
  }

  if (!profile) {
    throw new Error(
      "Student profile was not found."
    );
  }

  // ------------------------------------------
  // Prepare database record
  // ------------------------------------------

  const analysisRecord = {
    user_id: user.id,

    profile_id: profile.user_id,

    desired_career:
      result.desired_career ?? null,

    predicted_career:
      result.prediction?.best_career ?? null,

    confidence:
      result.prediction?.confidence ?? null,

    skill_match:
      result.alignment?.skill_match ?? null,

    alignment_level:
      result.alignment?.level ?? null,

    alignment_message:
      result.alignment?.message ?? null,

    model_name:
      "CareerCompass AI",

    model_version:
      "1.0.0",

    // Store the complete analysis
    analysis_data: result,
  };

  console.log(
    "Saving career analysis:",
    analysisRecord
  );

  // ------------------------------------------
  // Insert analysis
  // ------------------------------------------

  const {
    data,
    error,
  } = await supabase
    .from("career_analyses")
    .insert(analysisRecord)
    .select()
    .single();

  if (error) {
    throw error;
  }

  console.log(
    "Career analysis saved:",
    data
  );

  return data;
}

// ==========================================
// LOAD LATEST CAREER ANALYSIS
// ==========================================

export async function getLatestCareerAnalysis() {
  // ------------------------------------------
  // Get authenticated user
  // ------------------------------------------

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    return null;
  }

  // ------------------------------------------
  // Get latest analysis
  // ------------------------------------------

  const {
    data,
    error,
  } = await supabase
    .from("career_analyses")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", {
      ascending: false,
    })
    .limit(1)
    .maybeSingle();

  if (error) {
    throw error;
  }

  // No previous analysis
  if (!data) {
    return null;
  }

  // ------------------------------------------
  // Return complete stored analysis
  // ------------------------------------------

  if (data.analysis_data) {
    return data.analysis_data;
  }

  // Old records don't have analysis_data
  return null;
}

// ==========================================
// GET ANALYSIS HISTORY
// ==========================================

export async function getCareerAnalysisHistory() {
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  const { data, error } = await supabase
    .from("career_analyses")
    .select(`
      id,
      desired_career,
      predicted_career,
      confidence,
      skill_match,
      alignment_level,
      alignment_message,
      model_name,
      model_version,
      created_at,
      analysis_data
    `)
    .eq("user_id", user.id)
    .order("created_at", {
      ascending: false,
    });

  if (error) {
    throw error;
  }

  return data || [];
}