import { supabase } from "../lib/supabase";

// ==========================================
// SAVE ASSESSMENT RESULT
// ==========================================

export async function saveAssessmentResult({
  domain,
  score,
  correctAnswers,
  totalQuestions,
  level,
  answers = null,
}) {
  // ------------------------------------------
  // Get authenticated user
  // ------------------------------------------

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  // ------------------------------------------
  // Save result
  // ------------------------------------------

  const { data, error } = await supabase
    .from("skill_assessments")
    .insert({
      user_id: user.id,
      domain,
      score,
      correct_answers: correctAnswers,
      total_questions: totalQuestions,
      level,
      answers,
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  console.log("Assessment result saved:", data);

  return data;
}


// ==========================================
// GET ALL ASSESSMENT RESULTS
// ==========================================

export async function getAssessmentResults() {
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  const { data, error } = await supabase
    .from("skill_assessments")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", {
      ascending: false,
    });

  if (error) {
    throw error;
  }

  return data || [];
}


// ==========================================
// GET LATEST RESULT FOR A DOMAIN
// ==========================================

export async function getLatestAssessment(domain) {
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError) {
    throw userError;
  }

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  const { data, error } = await supabase
    .from("skill_assessments")
    .select("*")
    .eq("user_id", user.id)
    .eq("domain", domain)
    .order("created_at", {
      ascending: false,
    })
    .limit(1)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data || null;
}