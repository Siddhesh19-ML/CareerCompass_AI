import { supabase } from "../lib/supabase";

// ==========================================
// CURRENT USER
// ==========================================

export async function getCurrentUser() {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  return user;
}

// ==========================================
// GET STUDENT PROFILE
// ==========================================

export async function getStudentProfile() {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  const { data, error } = await supabase
    .from("student_profiles")
    .select("*")
    .eq("user_id", user.id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// SAVE STUDENT PROFILE
// ==========================================

export async function saveStudentProfile(profile) {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  const profileRecord = {
    user_id: user.id,

    age: profile.age,
    branch: profile.branch,
    semester: profile.semester,
    cgpa: profile.cgpa,
    backlog_count: profile.backlog_count,

    desired_career: profile.desired_career,

    profile_data: profile,
  };

  const { data, error } = await supabase
    .from("student_profiles")
    .upsert(profileRecord, {
      onConflict: "user_id",
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// UPLOAD RESUME
// ==========================================

export async function uploadResume(file) {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error("User is not authenticated.");
  }

  if (!file) {
    throw new Error("Please select a resume.");
  }

  if (file.type !== "application/pdf") {
    throw new Error("Only PDF resumes are supported.");
  }

  if (file.size > 5 * 1024 * 1024) {
    throw new Error(
      "Resume must be smaller than 5 MB."
    );
  }

  const filePath =
    `${user.id}/${Date.now()}-${file.name}`;

  const { error: uploadError } =
    await supabase.storage
      .from("resumes")
      .upload(filePath, file, {
        contentType: "application/pdf",
        upsert: false,
      });

  if (uploadError) {
    throw uploadError;
  }

  // Save storage path in profile
  const { error: profileError } =
    await supabase
      .from("student_profiles")
      .update({
        resume_url: filePath,
      })
      .eq("user_id", user.id);

  if (profileError) {
    throw profileError;
  }

  return filePath;
}

// ==========================================
// GET TEMPORARY RESUME URL
// ==========================================

export async function getResumeUrl(filePath) {
  if (!filePath) {
    return null;
  }

  const { data, error } =
    await supabase.storage
      .from("resumes")
      .createSignedUrl(
        filePath,
        60 * 10
      );

  if (error) {
    throw error;
  }

  return data.signedUrl;
}