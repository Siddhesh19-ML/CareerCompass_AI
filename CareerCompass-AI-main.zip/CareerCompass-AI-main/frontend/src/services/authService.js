import { supabase } from "../lib/supabase";

// ==========================================
// REGISTER USER
// ==========================================

export async function registerUser({
  email,
  password,
  fullName,
}) {
  const { data, error } =
    await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        },
      },
    });

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// LOGIN USER
// ==========================================

export async function loginUser({
  email,
  password,
}) {
  const { data, error } =
    await supabase.auth.signInWithPassword({
      email,
      password,
    });

  if (error) {
    throw error;
  }

  return data;
}

// ==========================================
// GET CURRENT USER
// ==========================================

export async function getCurrentUser() {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error) {
    return null;
  }

  return user;
}

// ==========================================
// GET USER ROLE
// ==========================================

export async function getUserRole() {
  const user = await getCurrentUser();

  if (!user) {
    return null;
  }

  return user.user_metadata?.role || null;
}

// ==========================================
// SAVE USER ROLE
// ==========================================

export async function setUserRole(role) {
  const validRoles = [
    "student",
    "recruiter",
  ];

  if (!validRoles.includes(role)) {
    throw new Error("Invalid user role.");
  }

  const { data, error } =
    await supabase.auth.updateUser({
      data: {
        role,
      },
    });

  if (error) {
    throw error;
  }

  return data.user;
}

// ==========================================
// LOGOUT
// ==========================================

export async function logoutUser() {
  const { error } =
    await supabase.auth.signOut();

  if (error) {
    throw error;
  }
}