import axios from "axios";

const API = axios.create({
  baseURL: "http://127.0.0.1:8000",
  headers: {
    "Content-Type": "application/json",
  },
});

export const analyzeCareer = async (
  studentProfile,
  desiredCareer
) => {
  const response = await API.post(
    "/career-analysis",
    {
      student_profile: studentProfile,
      desired_career: desiredCareer,
    }
  );

  return response.data;
};