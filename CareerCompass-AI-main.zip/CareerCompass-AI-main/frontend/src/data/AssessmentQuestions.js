export const assessmentDomains = [
  {
    id: "programming",
    title: "Programming",
    description:
      "Test your fundamentals of programming, logic and problem solving.",
    icon: "💻",
  },
  {
    id: "python",
    title: "Python",
    description:
      "Assess your Python programming knowledge and practical concepts.",
    icon: "🐍",
  },
  {
    id: "java",
    title: "Java",
    description:
      "Test Java fundamentals, OOP and programming concepts.",
    icon: "☕",
  },
  {
    id: "machine-learning",
    title: "Machine Learning",
    description:
      "Evaluate your understanding of machine learning concepts and algorithms.",
    icon: "🤖",
  },
  {
    id: "data-science",
    title: "Data Science",
    description:
      "Test statistics, data analysis and data science fundamentals.",
    icon: "📊",
  },
  {
    id: "web-development",
    title: "Web Development",
    description:
      "Assess HTML, CSS, JavaScript and modern web development concepts.",
    icon: "🌐",
  },
  {
    id: "database-sql",
    title: "Database & SQL",
    description:
      "Test SQL, database design and database management concepts.",
    icon: "🗄️",
  },
  {
    id: "cybersecurity",
    title: "Cybersecurity",
    description:
      "Evaluate your knowledge of security, networking and common attacks.",
    icon: "🔐",
  },
  {
    id: "cloud-computing",
    title: "Cloud Computing",
    description:
      "Test your understanding of cloud services, architecture and deployment.",
    icon: "☁️",
  },
  {
    id: "dsa",
    title: "Data Structures & Algorithms",
    description:
      "Assess your understanding of data structures, algorithms and complexity.",
    icon: "🧠",
  },
];

export const assessmentQuestions = {
  programming: [
    {
      id: 1,
      question:
        "Which data structure follows the Last In, First Out principle?",
      options: [
        "Queue",
        "Stack",
        "Linked List",
        "Array",
      ],
      answer: 1,
    },
    {
      id: 2,
      question:
        "What is the primary purpose of a function?",
      options: [
        "To store data permanently",
        "To group reusable code",
        "To create a database",
        "To compile a program",
      ],
      answer: 1,
    },
    {
      id: 3,
      question:
        "Which operator is commonly used to check equality?",
      options: [
        "=",
        "==",
        "!=",
        "+=",
      ],
      answer: 1,
    },
    {
      id: 4,
      question:
        "Which of the following is a loop?",
      options: [
        "if",
        "switch",
        "for",
        "class",
      ],
      answer: 2,
    },
    {
      id: 5,
      question:
        "What does an algorithm provide?",
      options: [
        "A step-by-step solution",
        "A database",
        "A programming language",
        "A compiler",
      ],
      answer: 0,
    },
    {
      id: 6,
      question:
        "Which concept allows the same interface to behave differently?",
      options: [
        "Encapsulation",
        "Inheritance",
        "Polymorphism",
        "Compilation",
      ],
      answer: 2,
    },
    {
      id: 7,
      question:
        "Which structure stores elements in sequential positions?",
      options: [
        "Array",
        "Graph",
        "Tree",
        "Hash function",
      ],
      answer: 0,
    },
    {
      id: 8,
      question:
        "What is debugging?",
      options: [
        "Writing documentation",
        "Finding and fixing program errors",
        "Compiling code",
        "Designing hardware",
      ],
      answer: 1,
    },
    {
      id: 9,
      question:
        "Which of these is NOT a programming language?",
      options: [
        "Python",
        "Java",
        "HTML",
        "C++",
      ],
      answer: 2,
    },
    {
      id: 10,
      question:
        "What is the main benefit of modular programming?",
      options: [
        "More reusable and maintainable code",
        "Larger files",
        "Slower execution",
        "Removing all errors",
      ],
      answer: 0,
    },
  ],

  python: [
    {
      id: 1,
      question:
        "Which keyword is used to define a function in Python?",
      options: [
        "function",
        "define",
        "def",
        "func",
      ],
      answer: 2,
    },
    {
      id: 2,
      question:
        "Which of the following is immutable?",
      options: [
        "List",
        "Dictionary",
        "Set",
        "Tuple",
      ],
      answer: 3,
    },
    {
      id: 3,
      question:
        "What does len() return?",
      options: [
        "Memory size",
        "Number of elements",
        "Data type",
        "Index",
      ],
      answer: 1,
    },
    {
      id: 4,
      question:
        "Which symbol is used for comments in Python?",
      options: [
        "//",
        "/* */",
        "#",
        "--",
      ],
      answer: 2,
    },
    {
      id: 5,
      question:
        "Which data type stores key-value pairs?",
      options: [
        "List",
        "Tuple",
        "Dictionary",
        "Set",
      ],
      answer: 2,
    },
    {
      id: 6,
      question:
        "What does the range() function commonly generate?",
      options: [
        "A sequence of numbers",
        "A dictionary",
        "A string",
        "A file",
      ],
      answer: 0,
    },
    {
      id: 7,
      question:
        "Which keyword handles exceptions?",
      options: [
        "catch",
        "try",
        "error",
        "handle",
      ],
      answer: 1,
    },
    {
      id: 8,
      question:
        "Which library is commonly used for numerical arrays?",
      options: [
        "NumPy",
        "Flask",
        "Django",
        "Requests",
      ],
      answer: 0,
    },
    {
      id: 9,
      question:
        "Which method adds an element to the end of a list?",
      options: [
        "add()",
        "insertEnd()",
        "append()",
        "push()",
      ],
      answer: 2,
    },
    {
      id: 10,
      question:
        "Which keyword is used to create a class?",
      options: [
        "object",
        "class",
        "struct",
        "type",
      ],
      answer: 1,
    },
  ],

  "machine-learning": [
    {
      id: 1,
      question:
        "Which is an example of supervised learning?",
      options: [
        "K-Means",
        "PCA",
        "Linear Regression",
        "Apriori",
      ],
      answer: 2,
    },
    {
      id: 2,
      question:
        "What is overfitting?",
      options: [
        "Poor training performance",
        "Good training but poor unseen-data performance",
        "Too little data",
        "Removing features",
      ],
      answer: 1,
    },
    {
      id: 3,
      question:
        "Which algorithm is commonly used for classification?",
      options: [
        "Logistic Regression",
        "PCA",
        "K-Means",
        "Apriori",
      ],
      answer: 0,
    },
    {
      id: 4,
      question:
        "What is the purpose of a test dataset?",
      options: [
        "Train the model",
        "Evaluate generalization",
        "Increase features",
        "Clean labels",
      ],
      answer: 1,
    },
    {
      id: 5,
      question:
        "Which metric is commonly used for classification?",
      options: [
        "Accuracy",
        "RMSE",
        "MAE",
        "R-squared",
      ],
      answer: 0,
    },
    {
      id: 6,
      question:
        "Which technique reduces dimensionality?",
      options: [
        "PCA",
        "KNN",
        "Random Forest",
        "Naive Bayes",
      ],
      answer: 0,
    },
    {
      id: 7,
      question:
        "What does a learning rate control?",
      options: [
        "Dataset size",
        "Step size during optimization",
        "Number of classes",
        "Number of features",
      ],
      answer: 1,
    },
    {
      id: 8,
      question:
        "Which algorithm is an ensemble method?",
      options: [
        "Random Forest",
        "KNN",
        "Linear Regression",
        "PCA",
      ],
      answer: 0,
    },
    {
      id: 9,
      question:
        "What is a feature?",
      options: [
        "A target prediction",
        "An input variable",
        "A model error",
        "A loss function",
      ],
      answer: 1,
    },
    {
      id: 10,
      question:
        "Which technique can help prevent overfitting?",
      options: [
        "Regularization",
        "Removing the test set",
        "Increasing noise",
        "Ignoring validation",
      ],
      answer: 0,
    },
  ],

  cybersecurity: [
    {
      id: 1,
      question:
        "What does CIA stand for in cybersecurity?",
      options: [
        "Confidentiality, Integrity, Availability",
        "Control, Identity, Access",
        "Cybersecurity, Intelligence, Authentication",
        "Confidentiality, Inspection, Authorization",
      ],
      answer: 0,
    },
    {
      id: 2,
      question:
        "Which protocol is commonly used for secure web communication?",
      options: [
        "HTTP",
        "FTP",
        "HTTPS",
        "Telnet",
      ],
      answer: 2,
    },
    {
      id: 3,
      question:
        "What does hashing primarily provide?",
      options: [
        "Reversible encryption",
        "One-way transformation",
        "Network routing",
        "File compression",
      ],
      answer: 1,
    },
    {
      id: 4,
      question:
        "Which attack attempts to inject malicious SQL?",
      options: [
        "DDoS",
        "SQL Injection",
        "Phishing",
        "Brute Force",
      ],
      answer: 1,
    },
    {
      id: 5,
      question:
        "What is phishing?",
      options: [
        "A database attack",
        "A social engineering attack",
        "A routing protocol",
        "An encryption method",
      ],
      answer: 1,
    },
    {
      id: 6,
      question:
        "Which Linux command lists files?",
      options: [
        "cd",
        "ls",
        "pwd",
        "mkdir",
      ],
      answer: 1,
    },
    {
      id: 7,
      question:
        "What is the purpose of a firewall?",
      options: [
        "Filter network traffic",
        "Create passwords",
        "Compress files",
        "Compile programs",
      ],
      answer: 0,
    },
    {
      id: 8,
      question:
        "What does MFA improve?",
      options: [
        "Authentication security",
        "Network speed",
        "Database size",
        "CPU performance",
      ],
      answer: 0,
    },
    {
      id: 9,
      question:
        "Which is a strong password practice?",
      options: [
        "Use the same password everywhere",
        "Use predictable personal information",
        "Use unique strong passwords",
        "Share passwords with friends",
      ],
      answer: 2,
    },
    {
      id: 10,
      question:
        "What is a vulnerability?",
      options: [
        "A security weakness",
        "A security patch",
        "A firewall",
        "A backup",
      ],
      answer: 0,
    },
  ],
};