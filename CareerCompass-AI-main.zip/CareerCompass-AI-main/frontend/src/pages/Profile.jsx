import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import ResumeUpload from "../components/ResumeUpload";

import {
  getStudentProfile,
  saveStudentProfile,
} from "../services/profileService";

import "./Profile.css";


// =========================================================
// DEFAULT PROFILE
// =========================================================

const defaultProfile = {
  age: 21,
  branch: "IT",
  semester: 7,
  cgpa: 8.5,
  backlog_count: 0,

  // -------------------------------------------------------
  // Keep these fields temporarily for backend compatibility.
  // They will no longer be edited manually.
  // Assessment + resume processing will populate them later.
  // -------------------------------------------------------

  python: 0,
  java: 0,
  cpp: 0,
  c: 0,
  javascript: 0,
  typescript: 0,
  sql: 0,
  html: 0,
  css: 0,
  php: 0,
  bash: 0,

  react: 0,
  angular: 0,
  vue: 0,
  nodejs: 0,
  express: 0,
  django: 0,
  flask: 0,
  springboot: 0,

  tensorflow: 0,
  pytorch: 0,
  scikit_learn: 0,
  pandas: 0,
  numpy: 0,
  opencv: 0,
  fastapi: 0,

  docker: 0,
  kubernetes: 0,
  aws: 0,
  azure: 0,
  gcp: 0,
  jenkins: 0,
  github_actions: 0,
  terraform: 0,
  ansible: 0,

  mysql: 0,
  postgresql: 0,
  mongodb: 0,
  redis: 0,
  firebase: 0,

  linux: 0,
  networking: 0,
  wireshark: 0,
  burpsuite: 0,
  metasploit: 0,
  nmap: 0,
  kali_linux: 0,
  owasp: 0,
  cryptography: 0,

  machine_learning: 0,
  deep_learning: 0,
  computer_vision: 0,
  nlp: 0,
  llm: 0,
  data_visualization: 0,
  statistics: 0,
  feature_engineering: 0,
  model_deployment: 0,

  android: 0,
  flutter: 0,
  react_native: 0,
  kotlin: 0,
  swift: 0,

  communication: 0,
  leadership: 0,
  teamwork: 0,
  adaptability: 0,
  presentation: 0,
  problem_solving: 0,
  critical_thinking: 0,

  dsa_score: 0,
  oop_score: 0,
  dbms_score: 0,
  os_score: 0,
  cn_score: 0,
  aptitude_score: 0,
  webdev_score: 0,
  ai_ml_score: 0,

  projects: 0,
  internships: 0,
  hackathons: 0,
  certifications: 0,
  research_papers: 0,
  open_source_contributions: 0,

  github_repositories: 0,
  github_stars: 0,
  github_followers: 0,
  github_contributions: 0,

  leetcode_solved: 0,
  leetcode_rating: 0,
  codechef_rating: 0,
  hackerrank_stars: 0,

  resume_score: 0,
  resume_projects_quality: 0,
  resume_keywords: 0,

  desired_career: "AI Engineer",
};


// =========================================================
// CAREER OPTIONS
// =========================================================

const careers = [
  "AI Engineer",
  "Data Scientist",
  "Cybersecurity Engineer",
  "Software Engineer",
  "Full Stack Developer",
  "Backend Developer",
  "Frontend Developer",
  "Cloud Engineer",
  "DevOps Engineer",
  "Mobile App Developer",
  "Business Analyst",
  "Data Analyst",
];


// =========================================================
// NUMBER FIELD
// =========================================================

function NumberField({
  label,
  name,
  value,
  onChange,
  min = 0,
  max,
  step = 1,
}) {
  return (
    <div className="profile-number-field">

      <label htmlFor={name}>
        {label}
      </label>

      <input
        id={name}
        type="number"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) =>
          onChange(
            name,
            e.target.value === ""
              ? ""
              : Number(e.target.value)
          )
        }
      />

    </div>
  );
}


// =========================================================
// PROFILE
// =========================================================

export default function Profile() {

  const navigate = useNavigate();

  const [profile, setProfile] =
    useState(defaultProfile);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [message, setMessage] =
    useState("");

  const [error, setError] =
    useState("");

  const [resumeDetected, setResumeDetected] =
    useState(false);

  const [detectedSkillCount, setDetectedSkillCount] =
    useState(0);


  // =======================================================
  // LOAD PROFILE
  // =======================================================

  useEffect(() => {

    async function loadProfile() {

      try {

        const data =
          await getStudentProfile();

        if (data?.profile_data) {

          setProfile({
            ...defaultProfile,
            ...data.profile_data,

            desired_career:
              data.desired_career ||
              data.profile_data.desired_career ||
              "AI Engineer",
          });

        }

      } catch (err) {

        console.error(err);

        setError(
          "Unable to load your profile."
        );

      } finally {

        setLoading(false);

      }
    }

    loadProfile();

  }, []);


  // =======================================================
  // UPDATE FIELD
  // =======================================================

  function updateField(name, value) {

    setProfile((current) => ({
      ...current,
      [name]: value,
    }));

  }


  // =======================================================
  // SAVE PROFILE
  // =======================================================

  async function handleSubmit(e) {

    e.preventDefault();

    setSaving(true);

    setMessage("");
    setError("");

    try {

      await saveStudentProfile(profile);

      setMessage(
        "Your career profile has been saved successfully."
      );

      setTimeout(() => {

        navigate("/dashboard");

      }, 800);

    } catch (err) {

      console.error(err);

      setError(
        err.message ||
        "Unable to save your profile."
      );

    } finally {

      setSaving(false);

    }
  }


  // =======================================================
  // LOADING
  // =======================================================

  if (loading) {

    return (
      <div className="app-loading">

        <div className="loading-content">

          <div className="loading-spinner" />

          <h2>
            CareerCompass AI
          </h2>

          <p>
            Loading your profile...
          </p>

        </div>

      </div>
    );

  }


  // =======================================================
  // PAGE
  // =======================================================

  return (

    <div className="profile-page">

      {/* ===================================================
          HEADER
          =================================================== */}

      <header className="profile-header">

        <div>

          <h1>
            CareerCompass AI
          </h1>

          <p>
            Build your personalized career profile
          </p>

        </div>

        <button
          type="button"
          className="secondary-button"
          onClick={() =>
            navigate("/dashboard")
          }
        >
          Dashboard
        </button>

      </header>


      {/* ===================================================
          MAIN
          =================================================== */}

      <main className="profile-container">


        {/* =================================================
            INTRO
            ================================================= */}

        <div className="profile-intro">

          <p className="eyebrow">
            CAREER PROFILE
          </p>

          <h2>
            Build your career profile
          </h2>

          <p>
            Tell us about your education, experience,
            projects and career goals. CareerCompass AI
            will use your resume and skill assessments
            to build your validated skill profile.
          </p>

        </div>


        <form onSubmit={handleSubmit}>


          {/* =================================================
              ACADEMIC INFORMATION
              ================================================= */}

          <section className="profile-section">

            <div className="section-heading">

              <h3>
                Academic Information
              </h3>

              <p>
                Basic academic details
              </p>

            </div>


            <div className="number-grid">

              <NumberField
                label="Age"
                name="age"
                value={profile.age}
                onChange={updateField}
                min={15}
                max={60}
              />

              <NumberField
                label="Semester"
                name="semester"
                value={profile.semester}
                onChange={updateField}
                min={1}
                max={12}
              />

              <NumberField
                label="CGPA"
                name="cgpa"
                value={profile.cgpa}
                onChange={updateField}
                min={0}
                max={10}
                step={0.1}
              />

              <NumberField
                label="Backlogs"
                name="backlog_count"
                value={profile.backlog_count}
                onChange={updateField}
                min={0}
                max={50}
              />


              <div className="profile-number-field">

                <label htmlFor="branch">
                  Branch
                </label>

                <select
                  id="branch"
                  value={profile.branch}
                  onChange={(e) =>
                    updateField(
                      "branch",
                      e.target.value
                    )
                  }
                >

                  <option value="IT">
                    Information Technology
                  </option>

                  <option value="Computer Science">
                    Computer Science
                  </option>

                  <option value="AI/DS">
                    AI / Data Science
                  </option>

                  <option value="Electronics">
                    Electronics
                  </option>

                  <option value="Mechanical">
                    Mechanical
                  </option>

                  <option value="Civil">
                    Civil
                  </option>

                  <option value="Other">
                    Other
                  </option>

                </select>

              </div>

            </div>

          </section>


          {/* =================================================
              SKILL VALIDATION
              ================================================= */}

          <section className="profile-section">

            <div className="section-heading">

              <h3>
                Skill Validation
              </h3>

              <p>
                Your skill level will be determined
                from assessments and resume evidence.
              </p>

            </div>


            <div
              style={{
                padding: "24px",
                borderRadius: "14px",
                border: "1px solid #1e293b",
                background:
                  "linear-gradient(145deg, #0f172a, #0b1427)",
              }}
            >

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "16px",
                  marginBottom: "16px",
                }}
              >

                <div
                  style={{
                    width: "48px",
                    height: "48px",
                    borderRadius: "12px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background:
                      "rgba(34, 211, 238, 0.08)",
                    border:
                      "1px solid rgba(34, 211, 238, 0.2)",
                    color: "#67e8f9",
                    fontSize: "20px",
                  }}
                >
                  ✓
                </div>


                <div>

                  <strong
                    style={{
                      display: "block",
                      color: "#f8fafc",
                      fontSize: "15px",
                    }}
                  >
                    No manual skill rating
                  </strong>

                  <span
                    style={{
                      display: "block",
                      marginTop: "4px",
                      color: "#71819c",
                      fontSize: "12px",
                    }}
                  >
                    CareerCompass will evaluate your
                    skills using actual evidence.
                  </span>

                </div>

              </div>


              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2, minmax(0, 1fr))",
                  gap: "12px",
                }}
              >

                <div
                  style={{
                    padding: "15px",
                    borderRadius: "10px",
                    background: "#0b1427",
                    border: "1px solid #1e293b",
                  }}
                >

                  <strong
                    style={{
                      display: "block",
                      color: "#f8fafc",
                      fontSize: "13px",
                    }}
                  >
                    📄 Resume Evidence
                  </strong>

                  <span
                    style={{
                      display: "block",
                      marginTop: "5px",
                      color: "#71819c",
                      fontSize: "11px",
                    }}
                  >
                    Skills, projects and technologies
                    detected from your resume.
                  </span>

                </div>


                <div
                  style={{
                    padding: "15px",
                    borderRadius: "10px",
                    background: "#0b1427",
                    border: "1px solid #1e293b",
                  }}
                >

                  <strong
                    style={{
                      display: "block",
                      color: "#f8fafc",
                      fontSize: "13px",
                    }}
                  >
                    🧠 Skill Assessments
                  </strong>

                  <span
                    style={{
                      display: "block",
                      marginTop: "5px",
                      color: "#71819c",
                      fontSize: "11px",
                    }}
                  >
                    Your actual performance in
                    technical domains.
                  </span>

                </div>

              </div>


              {resumeDetected && (

                <div
                  style={{
                    marginTop: "16px",
                    padding: "12px 14px",
                    borderRadius: "9px",
                    background:
                      "rgba(16, 185, 129, 0.07)",
                    border:
                      "1px solid rgba(16, 185, 129, 0.25)",
                    color: "#6ee7b7",
                    fontSize: "12px",
                  }}
                >

                  Resume analyzed successfully.
                  {" "}
                  {detectedSkillCount} skills detected.

                </div>

              )}

            </div>

          </section>


          {/* =================================================
              EXPERIENCE
              ================================================= */}

          <section className="profile-section">

            <div className="section-heading">

              <h3>
                Experience & Online Profiles
              </h3>

              <p>
                Add your projects, experience and
                developer activity.
              </p>

            </div>


            <div className="number-grid">

              <NumberField
                label="Projects"
                name="projects"
                value={profile.projects}
                onChange={updateField}
                min={0}
                max={100}
              />

              <NumberField
                label="Internships"
                name="internships"
                value={profile.internships}
                onChange={updateField}
                min={0}
                max={50}
              />

              <NumberField
                label="Hackathons"
                name="hackathons"
                value={profile.hackathons}
                onChange={updateField}
                min={0}
                max={100}
              />

              <NumberField
                label="Certifications"
                name="certifications"
                value={profile.certifications}
                onChange={updateField}
                min={0}
                max={100}
              />

              <NumberField
                label="Research Papers"
                name="research_papers"
                value={profile.research_papers}
                onChange={updateField}
                min={0}
                max={100}
              />

              <NumberField
                label="Open Source Contributions"
                name="open_source_contributions"
                value={profile.open_source_contributions}
                onChange={updateField}
                min={0}
                max={10000}
              />

              <NumberField
                label="GitHub Repositories"
                name="github_repositories"
                value={profile.github_repositories}
                onChange={updateField}
                min={0}
                max={10000}
              />

              <NumberField
                label="GitHub Stars"
                name="github_stars"
                value={profile.github_stars}
                onChange={updateField}
                min={0}
                max={100000}
              />

              <NumberField
                label="GitHub Followers"
                name="github_followers"
                value={profile.github_followers}
                onChange={updateField}
                min={0}
                max={1000000}
              />

              <NumberField
                label="GitHub Contributions"
                name="github_contributions"
                value={profile.github_contributions}
                onChange={updateField}
                min={0}
                max={100000}
              />

              <NumberField
                label="LeetCode Solved"
                name="leetcode_solved"
                value={profile.leetcode_solved}
                onChange={updateField}
                min={0}
                max={10000}
              />

              <NumberField
                label="LeetCode Rating"
                name="leetcode_rating"
                value={profile.leetcode_rating}
                onChange={updateField}
                min={0}
                max={5000}
              />

              <NumberField
                label="CodeChef Rating"
                name="codechef_rating"
                value={profile.codechef_rating}
                onChange={updateField}
                min={0}
                max={5000}
              />

              <NumberField
                label="HackerRank Stars"
                name="hackerrank_stars"
                value={profile.hackerrank_stars}
                onChange={updateField}
                min={0}
                max={10}
              />

            </div>

          </section>


          {/* =================================================
              CAREER GOAL
              ================================================= */}

          <section className="profile-section">

            <div className="section-heading">

              <h3>
                Career Goal
              </h3>

              <p>
                Which career are you targeting?
              </p>

            </div>


            <select
              className="career-select"
              value={profile.desired_career}
              onChange={(e) =>
                updateField(
                  "desired_career",
                  e.target.value
                )
              }
            >

              {careers.map((career) => (

                <option
                  key={career}
                  value={career}
                >
                  {career}
                </option>

              ))}

            </select>

          </section>


          {/* =================================================
              MESSAGES
              ================================================= */}

          {message && (

            <div className="success-message">
              {message}
            </div>

          )}


          {error && (

            <div className="error-message">
              {error}
            </div>

          )}


          {/* =================================================
              RESUME
              ================================================= */}

          <ResumeUpload

            onExtracted={(result) => {

              console.log(
                "Extracted resume data:",
                result
              );

              const resumeData =
                result?.result;

              if (!resumeData) {

                setError(
                  "Unable to read extracted resume data."
                );

                return;

              }


              const skills =
                resumeData.skills || [];


              // ---------------------------------------------
              // Resume skill mapping
              // ---------------------------------------------

              const skillMap = {

                python: "python",
                java: "java",
                "c++": "cpp",
                c: "c",
                javascript: "javascript",
                typescript: "typescript",
                sql: "sql",
                html: "html",
                css: "css",

                react: "react",
                angular: "angular",
                vue: "vue",
                nodejs: "nodejs",
                express: "express",
                django: "django",
                flask: "flask",
                fastapi: "fastapi",

                tensorflow: "tensorflow",
                pytorch: "pytorch",
                "scikit-learn": "scikit_learn",
                pandas: "pandas",
                numpy: "numpy",
                opencv: "opencv",

                "machine learning":
                  "machine_learning",

                "deep learning":
                  "deep_learning",

                nlp: "nlp",
                llm: "llm",

                docker: "docker",
                kubernetes: "kubernetes",
                aws: "aws",
                azure: "azure",
                gcp: "gcp",
                jenkins: "jenkins",
                terraform: "terraform",

                linux: "linux",
                networking: "networking",
                wireshark: "wireshark",
                burpsuite: "burpsuite",
                metasploit: "metasploit",
                nmap: "nmap",

                "kali linux":
                  "kali_linux",

                owasp: "owasp",
                cryptography:
                  "cryptography",

              };


              // ---------------------------------------------
              // IMPORTANT
              //
              // Do NOT assign a proficiency score here.
              //
              // Resume detection = evidence only.
              //
              // Assessment will later determine the
              // actual skill score.
              // ---------------------------------------------

              setProfile((current) => {

                const updated = {
                  ...current,
                };


                // Project count

                if (
                  typeof resumeData.project_count ===
                  "number"
                ) {

                  updated.projects =
                    resumeData.project_count;

                }


                // Internship count

                if (
                  typeof resumeData.internship_count ===
                  "number"
                ) {

                  updated.internships =
                    resumeData.internship_count;

                }


                // Certification count

                if (
                  typeof resumeData.certification_count ===
                  "number"
                ) {

                  updated.certifications =
                    resumeData.certification_count;

                }


                // Research paper count

                if (
                  typeof resumeData.research_count ===
                  "number"
                ) {

                  updated.research_papers =
                    resumeData.research_count;

                }


                // GitHub repositories

                if (
                  Array.isArray(
                    resumeData.github
                  )
                ) {

                  updated.github_repositories =
                    resumeData.github.length;

                }


                // Resume keyword count

                if (
                  typeof resumeData.skill_count ===
                  "number"
                ) {

                  updated.resume_keywords =
                    resumeData.skill_count;

                }


                // Keep skill mapping available for
                // future validated-skill processing.
                //
                // We deliberately DO NOT set:
                //
                // updated[fieldName] = 4
                //
                // because resume detection should not
                // automatically imply proficiency.

                return updated;

              });


              setDetectedSkillCount(
                skills.length
              );

              setResumeDetected(true);

              setError("");

              setMessage(
                `Resume analyzed successfully. ${skills.length} skills detected and ${
                  resumeData.project_count || 0
                } projects detected.`
              );

            }}

          />


          {/* =================================================
              SAVE
              ================================================= */}

          <div className="profile-submit">

            <button
              type="submit"
              className="primary-button"
              disabled={saving}
            >

              {saving
                ? "Saving Profile..."
                : "Save Career Profile"}

            </button>

          </div>


        </form>

      </main>

    </div>

  );
}