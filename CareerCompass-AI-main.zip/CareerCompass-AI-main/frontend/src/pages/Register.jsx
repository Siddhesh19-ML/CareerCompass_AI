import { useState } from "react";

import {
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";

import {
  registerUser,
  setUserRole,
} from "../services/authService";

import "./Auth.css";

export default function Register() {
  const navigate = useNavigate();
  const location = useLocation();

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  function handleChange(e) {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();

    setError("");
    setSuccess("");

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must contain at least 6 characters.");
      return;
    }

    setLoading(true);

    try {
      const data = await registerUser({
        fullName: formData.fullName,
        email: formData.email,
        password: formData.password,
      });

      if (data.session) {
        const selectedRole =
          location.state?.role ||
          sessionStorage.getItem(
            "careercompass_pending_role"
          );

        if (selectedRole) {
          await setUserRole(selectedRole);

          sessionStorage.removeItem(
            "careercompass_pending_role"
          );

          navigate("/profile");
        } else {
          navigate("/role-selection", {
            state: {
              from: "register",
            },
          });
        }

        return;
      }

      setSuccess(
        "Account created successfully. Please check your email to verify your account."
      );

      setFormData({
        fullName: "",
        email: "",
        password: "",
        confirmPassword: "",
      });
    } catch (err) {
      setError(
        err.message ||
          "Unable to create your account. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="register-page">

      {/* Background effects */}
      <div className="auth-glow auth-glow-one"></div>
      <div className="auth-glow auth-glow-two"></div>

      {/* Navigation */}
      <header className="auth-navbar">

        <div className="auth-navbar-inner">

          <Link to="/" className="auth-brand">

            <div className="auth-brand-mark">
              CC
            </div>

            <div>
              <div className="auth-brand-name">
                CareerCompass AI
              </div>

              <div className="auth-brand-subtitle">
                CAREER INTELLIGENCE
              </div>
            </div>

          </Link>

          <Link
            to="/"
            className="auth-back"
          >
            Back to home
          </Link>

        </div>

      </header>

      {/* Main registration area */}
      <main className="register-main">

        <div className="register-card">

          <div className="register-card-top">

            <div className="register-icon">
              CC
            </div>

            <div className="register-secure">
              CREATE YOUR PROFILE
            </div>

          </div>

          <div className="register-header">

            <div className="register-label">
              <span></span>
              GET STARTED
            </div>

            <h1>
              Create your account
            </h1>

            <p>
              Start building your personalized career
              intelligence profile.
            </p>

          </div>

          {error && (
            <div className="auth-error">
              {error}
            </div>
          )}

          {success && (
            <div className="auth-success">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit}>

            <div className="register-form-group">

              <label htmlFor="fullName">
                Full name
              </label>

              <input
                id="fullName"
                name="fullName"
                type="text"
                placeholder="Enter your full name"
                value={formData.fullName}
                onChange={handleChange}
                autoComplete="name"
                required
              />

            </div>

            <div className="register-form-group">

              <label htmlFor="email">
                Email address
              </label>

              <input
                id="email"
                name="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={handleChange}
                autoComplete="email"
                required
              />

            </div>

            <div className="register-form-row">

              <div className="register-form-group">

                <label htmlFor="password">
                  Password
                </label>

                <input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Minimum 6 characters"
                  value={formData.password}
                  onChange={handleChange}
                  autoComplete="new-password"
                  minLength={6}
                  required
                />

              </div>

              <div className="register-form-group">

                <label htmlFor="confirmPassword">
                  Confirm password
                </label>

                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="Re-enter password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  autoComplete="new-password"
                  required
                />

              </div>

            </div>

            <button
              type="submit"
              className="register-submit"
              disabled={loading}
            >

              {loading ? (
                <span className="register-submit-content">
                  <span className="loading-spinner"></span>
                  Creating account...
                </span>
              ) : (
                <span className="register-submit-content">
                  Create Account
                  <span className="submit-arrow">
                    →
                  </span>
                </span>
              )}

            </button>

          </form>

          <div className="register-divider">
            <span>
              Already have an account?
            </span>
          </div>

          <Link
            to="/login"
            className="register-secondary"
          >
            Sign In
            <span>→</span>
          </Link>

          <div className="register-security">

            <span className="security-dot"></span>

            Your account and career profile are securely
            associated with your credentials.

          </div>

        </div>

      </main>

    </div>
  );
}