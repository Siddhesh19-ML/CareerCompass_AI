import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  assessmentDomains,
  assessmentQuestions,
} from "../data/assessmentQuestions";

import { saveAssessmentResult } from "../services/assessmentService";

import "./Assessment.css";

export default function Assessment() {
  const navigate = useNavigate();

  const [selectedDomain, setSelectedDomain] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");

  // -----------------------------------------
  // GET CURRENT QUESTIONS
  // -----------------------------------------

  const questions =
    selectedDomain &&
    assessmentQuestions[selectedDomain.id]
      ? assessmentQuestions[selectedDomain.id]
      : [];

  // -----------------------------------------
  // START ASSESSMENT
  // -----------------------------------------

  function startAssessment(domain) {
    if (!assessmentQuestions[domain.id]) {
      return;
    }

    setSelectedDomain(domain);
    setCurrentQuestion(0);
    setAnswers({});
    setSubmitted(false);
    setSaveError("");

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  // -----------------------------------------
  // SELECT ANSWER
  // -----------------------------------------

  function selectAnswer(optionIndex) {
    setAnswers((previous) => ({
      ...previous,
      [currentQuestion]: optionIndex,
    }));
  }

  // -----------------------------------------
  // NEXT QUESTION
  // -----------------------------------------

  function nextQuestion() {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((previous) => previous + 1);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }
  }

  // -----------------------------------------
  // PREVIOUS QUESTION
  // -----------------------------------------

  function previousQuestion() {
    if (currentQuestion > 0) {
      setCurrentQuestion((previous) => previous - 1);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }
  }

  // -----------------------------------------
  // CALCULATE SCORE
  // -----------------------------------------

  function calculateScore() {
    let correct = 0;

    questions.forEach((question, index) => {
      if (answers[index] === question.answer) {
        correct++;
      }
    });

    return correct;
  }

  // -----------------------------------------
  // CALCULATE RESULT
  // -----------------------------------------

  function getResult() {
    const correct = calculateScore();

    const total = questions.length;

    const percentage =
      total > 0
        ? Math.round((correct / total) * 100)
        : 0;

    let level = "Beginner";

    if (percentage >= 80) {
      level = "Advanced";
    } else if (percentage >= 60) {
      level = "Intermediate";
    }

    return {
      correct,
      total,
      percentage,
      level,
    };
  }

  // -----------------------------------------
  // SUBMIT ASSESSMENT
  // -----------------------------------------

  async function submitAssessment() {
    if (saving) {
      return;
    }

    setSaveError("");
    setSaving(true);

    try {
      const result = getResult();

      // Save assessment result to Supabase
      await saveAssessmentResult({
        domain: selectedDomain.id,
        score: result.percentage,
        correctAnswers: result.correct,
        totalQuestions: result.total,
        level: result.level,
        answers,
      });

      console.log("Assessment saved successfully:", {
        domain: selectedDomain.id,
        ...result,
      });

      // Only show result after successful save
      setSubmitted(true);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    } catch (err) {
      console.error("Assessment save error:", err);

      setSaveError(
        err.message ||
          "Unable to save your assessment result. Please try again."
      );
    } finally {
      setSaving(false);
    }
  }

  // =========================================
  // RESULT SCREEN
  // =========================================

  if (selectedDomain && submitted) {
    const result = getResult();

    return (
      <div className="assessment-page">

        <main className="assessment-container">

          <div className="assessment-result">

            <div className="assessment-result-label">
              ASSESSMENT COMPLETE
            </div>

            <div className="assessment-result-icon">
              ✓
            </div>

            <h1>
              {selectedDomain.title}
            </h1>

            <p className="assessment-result-subtitle">
              Here's how you performed in this assessment.
            </p>

            {/* SCORE */}

            <div className="assessment-score-card">

              <div className="assessment-score">
                {result.percentage}%
              </div>

              <div className="assessment-level">
                {result.level}
              </div>

              <div className="assessment-score-bar">
                <div
                  className="assessment-score-fill"
                  style={{
                    width: `${result.percentage}%`,
                  }}
                />
              </div>

            </div>

            {/* STATS */}

            <div className="assessment-result-stats">

              <div className="assessment-stat">
                <span>
                  Correct Answers
                </span>

                <strong>
                  {result.correct}
                </strong>
              </div>

              <div className="assessment-stat">
                <span>
                  Incorrect Answers
                </span>

                <strong>
                  {result.total - result.correct}
                </strong>
              </div>

              <div className="assessment-stat">
                <span>
                  Total Questions
                </span>

                <strong>
                  {result.total}
                </strong>
              </div>

            </div>

            {/* MESSAGE */}

            <div className="assessment-result-message">

              {result.percentage >= 80 && (
                <>
                  <strong>
                    Excellent performance.
                  </strong>

                  <p>
                    You demonstrated strong knowledge
                    in {selectedDomain.title}.
                  </p>
                </>
              )}

              {result.percentage >= 60 &&
                result.percentage < 80 && (
                  <>
                    <strong>
                      Good foundation.
                    </strong>

                    <p>
                      You have a solid understanding,
                      but there are still areas worth
                      strengthening.
                    </p>
                  </>
                )}

              {result.percentage < 60 && (
                <>
                  <strong>
                    Room for improvement.
                  </strong>

                  <p>
                    Use this result to identify areas
                    that need more practice.
                  </p>
                </>
              )}

            </div>

            {/* ACTIONS */}

            <div className="assessment-result-actions">

              <button
                className="assessment-secondary-button"
                onClick={() => {
                  setSelectedDomain(null);
                  setSubmitted(false);
                  setAnswers({});
                  setCurrentQuestion(0);
                  setSaveError("");
                }}
              >
                Take Another Assessment
              </button>

              <button
                className="assessment-primary-button"
                onClick={() =>
                  navigate("/dashboard")
                }
              >
                Back to Dashboard
              </button>

            </div>

          </div>

        </main>

      </div>
    );
  }

  // =========================================
  // QUESTION SCREEN
  // =========================================

  if (selectedDomain) {
    const question =
      questions[currentQuestion];

    const progress =
      ((currentQuestion + 1) /
        questions.length) *
      100;

    const isLastQuestion =
      currentQuestion ===
      questions.length - 1;

    const hasAnswer =
      answers[currentQuestion] !== undefined;

    return (
      <div className="assessment-page">

        <main className="assessment-container">

          {/* TOP */}

          <div className="assessment-top">

            <button
              className="assessment-back"
              onClick={() => {
                if (saving) return;

                setSelectedDomain(null);
                setAnswers({});
                setCurrentQuestion(0);
                setSaveError("");
              }}
              disabled={saving}
            >
              ← All Assessments
            </button>

            <div className="assessment-domain-title">

              <span>
                {selectedDomain.icon}
              </span>

              <div>
                <strong>
                  {selectedDomain.title}
                </strong>

                <small>
                  Skill Assessment
                </small>
              </div>

            </div>

          </div>

          {/* PROGRESS */}

          <div className="assessment-progress-section">

            <div className="assessment-progress-info">

              <span>
                Question {currentQuestion + 1}{" "}
                of {questions.length}
              </span>

              <span>
                {Math.round(progress)}%
              </span>

            </div>

            <div className="assessment-progress-bar">

              <div
                className="assessment-progress-fill"
                style={{
                  width: `${progress}%`,
                }}
              />

            </div>

          </div>

          {/* QUESTION */}

          <div className="assessment-question-card">

            <div className="assessment-question-number">
              QUESTION {currentQuestion + 1}
            </div>

            <h1>
              {question.question}
            </h1>

            <div className="assessment-options">

              {question.options.map(
                (option, index) => {

                  const selected =
                    answers[currentQuestion] ===
                    index;

                  return (
                    <button
                      key={option}
                      type="button"
                      className={`assessment-option ${
                        selected
                          ? "assessment-option-selected"
                          : ""
                      }`}
                      onClick={() =>
                        selectAnswer(index)
                      }
                      disabled={saving}
                    >

                      <span className="assessment-option-letter">
                        {String.fromCharCode(
                          65 + index
                        )}
                      </span>

                      <span>
                        {option}
                      </span>

                      {selected && (
                        <span className="assessment-option-check">
                          ✓
                        </span>
                      )}

                    </button>
                  );
                }
              )}

            </div>

          </div>

          {/* SAVE ERROR */}

          {saveError && (
            <div className="error-message">
              {saveError}
            </div>
          )}

          {/* NAVIGATION */}

          <div className="assessment-navigation">

            <button
              type="button"
              className="assessment-secondary-button"
              onClick={previousQuestion}
              disabled={
                currentQuestion === 0 ||
                saving
              }
            >
              ← Previous
            </button>

            {!isLastQuestion ? (
              <button
                type="button"
                className="assessment-primary-button"
                onClick={nextQuestion}
                disabled={
                  !hasAnswer ||
                  saving
                }
              >
                Next Question →
              </button>
            ) : (
              <button
                type="button"
                className="assessment-primary-button"
                onClick={submitAssessment}
                disabled={
                  !hasAnswer ||
                  saving
                }
              >
                {saving
                  ? "Saving Result..."
                  : "Submit Assessment ✓"}
              </button>
            )}

          </div>

        </main>

      </div>
    );
  }

  // =========================================
  // DOMAIN SELECTION SCREEN
  // =========================================

  return (
    <div className="assessment-page">

      <main className="assessment-container">

        {/* HEADER */}

        <section className="assessment-header">

          <div className="assessment-label">
            <span></span>
            SKILL VALIDATION
          </div>

          <h1>
            Test your skills
          </h1>

          <p>
            Take short assessments to validate
            your current knowledge and help
            CareerCompass AI understand your
            strengths more accurately.
          </p>

        </section>

        {/* INFO */}

        <div className="assessment-info">

          <div>
            <strong>
              How it works
            </strong>

            <span>
              Choose a domain and answer 10
              multiple-choice questions.
            </span>
          </div>

          <div>
            <strong>
              No negative marking
            </strong>

            <span>
              Your score is based only on correct
              answers.
            </span>
          </div>

          <div>
            <strong>
              Used for career analysis
            </strong>

            <span>
              Your results can strengthen your
              skill and career recommendations.
            </span>
          </div>

        </div>

        {/* DOMAINS */}

        <section>

          <div className="assessment-section-heading">

            <h2>
              Choose an assessment
            </h2>

            <span>
              {Object.keys(assessmentQuestions).length} available
            </span>

          </div>

          <div className="assessment-domain-grid">

            {assessmentDomains.map(
              (domain) => {

                const available =
                  Boolean(
                    assessmentQuestions[
                      domain.id
                    ]
                  );

                return (
                  <button
                    key={domain.id}
                    type="button"
                    className={`assessment-domain-card ${
                      !available
                        ? "assessment-domain-disabled"
                        : ""
                    }`}
                    onClick={() =>
                      available &&
                      startAssessment(domain)
                    }
                    disabled={!available}
                  >

                    <div className="assessment-domain-icon">
                      {domain.icon}
                    </div>

                    <div className="assessment-domain-content">

                      <h3>
                        {domain.title}
                      </h3>

                      <p>
                        {domain.description}
                      </p>

                      <span
                        className={
                          available
                            ? "assessment-available"
                            : "assessment-coming-soon"
                        }
                      >
                        {available
                          ? "10 Questions →"
                          : "Coming Soon"}
                      </span>

                    </div>

                  </button>
                );
              }
            )}

          </div>

        </section>

        {/* BACK */}

        <div className="assessment-bottom">

          <button
            className="assessment-secondary-button"
            onClick={() =>
              navigate("/dashboard")
            }
          >
            ← Back to Dashboard
          </button>

        </div>

      </main>

    </div>
  );
}