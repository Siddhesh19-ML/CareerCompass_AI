import React from "react";
import { Link } from "react-router-dom";
import "./Landing.css";

const features = [
  {
    number: "01",
    title: "AI Career Prediction",
    description:
      "Discover career paths that match your academics, technical skills, experience and goals.",
  },
  {
    number: "02",
    title: "Resume Intelligence",
    description:
      "Upload your resume and automatically extract relevant skills, projects and education.",
  },
  {
    number: "03",
    title: "Skill Gap Analysis",
    description:
      "Understand which skills strengthen your target career and which areas need improvement.",
  },
  {
    number: "04",
    title: "Personalized Roadmap",
    description:
      "Get a structured learning roadmap based on your current profile and desired career.",
  },
  {
    number: "05",
    title: "Profile Intelligence",
    description:
      "Build a complete profile covering academics, technical skills, assessments and experience.",
  },
  {
    number: "06",
    title: "Analysis History",
    description:
      "Review previous career analyses and track how your career profile evolves.",
  },
];

const steps = [
  {
    number: "01",
    title: "Build your profile",
    description:
      "Add your academic information, technical skills, assessments, projects and career goal.",
  },
  {
    number: "02",
    title: "Analyze your resume",
    description:
      "Upload your resume and let CareerCompass extract useful career information automatically.",
  },
  {
    number: "03",
    title: "Discover your career match",
    description:
      "Our machine learning system evaluates your profile against suitable career paths.",
  },
  {
    number: "04",
    title: "Follow your roadmap",
    description:
      "Identify your skill gaps and receive a personalized path toward your target career.",
  },
];

function Landing() {
  return (
    <div className="landing-page">

      {/* Background effects */}
      <div className="landing-glow landing-glow-one"></div>
      <div className="landing-glow landing-glow-two"></div>

      {/* NAVBAR */}
      <header className="landing-navbar">
        <div className="landing-container navbar-inner">

          <Link to="/" className="brand">
            <div className="brand-mark">
              CC
            </div>

            <div>
              <div className="brand-name">
                CareerCompass AI
              </div>

              <div className="brand-subtitle">
                CAREER INTELLIGENCE
              </div>
            </div>
          </Link>

          <nav className="desktop-nav">
            <a href="#features">Features</a>
            <a href="#how-it-works">How it works</a>
            <a href="#about">About</a>
          </nav>

          <div className="navbar-actions">
            <Link
              to="/login"
              className="nav-login"
            >
              Sign in
            </Link>

            <Link
              to="/roles"
              className="nav-cta"
            >
              Get Started
            </Link>
          </div>

        </div>
      </header>

      {/* HERO */}
      <main>

        <section className="hero-section">
          <div className="landing-container hero-grid">

            {/* Hero content */}
            <div className="hero-content">

              <div className="hero-label">
                <span className="status-dot"></span>
                AI CAREER INTELLIGENCE
              </div>

              <h1>
                Build a career path
                <span> based on your actual profile.</span>
              </h1>

              <p className="hero-description">
                CareerCompass AI combines your academics, technical skills,
                projects, experience and career goals to generate
                personalized career intelligence.
              </p>

              <div className="hero-buttons">
                <Link
                  to="/roles"
                  className="primary-button"
                >
                  Analyze My Career
                  <span>→</span>
                </Link>

                <a
                  href="#features"
                  className="secondary-button"
                >
                  Explore Platform
                </a>
              </div>

              <div className="hero-points">
                <span>AI-powered analysis</span>
                <span>Resume intelligence</span>
                <span>Personalized roadmap</span>
              </div>

            </div>

            {/* Dashboard preview */}
            <div className="dashboard-preview-wrapper">

              <div className="preview-glow"></div>

              <div className="dashboard-preview">

                <div className="preview-header">
                  <div>
                    <div className="preview-label">
                      CAREER INTELLIGENCE
                    </div>

                    <h2>
                      Your Career Overview
                    </h2>
                  </div>

                  <div className="preview-icon">
                    AI
                  </div>
                </div>

                <div className="preview-metrics">

                  <div className="metric-card">
                    <div className="metric-label">
                      Career Match
                    </div>

                    <div className="metric-value cyan">
                      92%
                    </div>

                    <div className="progress-track">
                      <div
                        className="progress-fill cyan-fill"
                        style={{ width: "92%" }}
                      ></div>
                    </div>
                  </div>

                  <div className="metric-card">
                    <div className="metric-label">
                      Confidence
                    </div>

                    <div className="metric-value purple">
                      96%
                    </div>

                    <div className="progress-track">
                      <div
                        className="progress-fill purple-fill"
                        style={{ width: "96%" }}
                      ></div>
                    </div>
                  </div>

                </div>

                <div className="career-match-card">

                  <div>
                    <div className="metric-label">
                      RECOMMENDED CAREER
                    </div>

                    <h3>
                      AI / ML Engineer
                    </h3>

                    <p>
                      Your technical profile shows strong alignment
                      with artificial intelligence and machine learning roles.
                    </p>
                  </div>

                  <span className="match-badge">
                    Strong Match
                  </span>

                </div>

                <div className="skills-card">

                  <div className="skills-header">
                    <strong>Skill Match</strong>
                    <span>87%</span>
                  </div>

                  {[
                    ["Python", "92%"],
                    ["Machine Learning", "84%"],
                    ["SQL", "78%"],
                    ["Cloud", "61%"],
                  ].map(([skill, value]) => (
                    <div
                      className="skill-row"
                      key={skill}
                    >
                      <div className="skill-info">
                        <span>{skill}</span>
                        <span>{value}</span>
                      </div>

                      <div className="progress-track">
                        <div
                          className="progress-fill skill-fill"
                          style={{ width: value }}
                        ></div>
                      </div>
                    </div>
                  ))}

                </div>

                <div className="roadmap-preview">

                  <div>
                    <div className="metric-label">
                      PERSONALIZED ROADMAP
                    </div>

                    <strong>
                      4 learning stages identified
                    </strong>
                  </div>

                  <span className="roadmap-arrow">
                    →
                  </span>

                </div>

              </div>
            </div>

          </div>
        </section>

        {/* STATS */}
        <section className="stats-section">
          <div className="landing-container stats-grid">

            <div className="stat">
              <strong>AI</strong>
              <span>Career Intelligence</span>
            </div>

            <div className="stat">
              <strong>360°</strong>
              <span>Profile Analysis</span>
            </div>

            <div className="stat">
              <strong>ML</strong>
              <span>Driven Predictions</span>
            </div>

            <div className="stat">
              <strong>1:1</strong>
              <span>Personalized Roadmap</span>
            </div>

          </div>
        </section>

        {/* FEATURES */}
        <section
          id="features"
          className="features-section"
        >
          <div className="landing-container">

            <div className="section-heading">

              <div className="section-label">
                PLATFORM CAPABILITIES
              </div>

              <h2>
                One profile.
                <span>A clearer career direction.</span>
              </h2>

              <p>
                CareerCompass AI brings the most important parts of
                career preparation into one intelligent platform.
              </p>

            </div>

            <div className="features-grid">

              {features.map((feature) => (
                <div
                  className="feature-card"
                  key={feature.number}
                >

                  <div className="feature-number">
                    {feature.number}
                  </div>

                  <h3>
                    {feature.title}
                  </h3>

                  <p>
                    {feature.description}
                  </p>

                  <div className="feature-line"></div>

                </div>
              ))}

            </div>

          </div>
        </section>

        {/* HOW IT WORKS */}
        <section
          id="how-it-works"
          className="workflow-section"
        >
          <div className="landing-container workflow-grid">

            <div className="workflow-intro">

              <div className="section-label">
                HOW IT WORKS
              </div>

              <h2>
                From profile to
                <span>career direction.</span>
              </h2>

              <p>
                Start with the information you already have.
                CareerCompass transforms it into useful career
                intelligence and a practical path forward.
              </p>

              <Link
                to="/roles"
                className="workflow-button"
              >
                Build Your Profile
                <span>→</span>
              </Link>

            </div>

            <div className="workflow-steps">

              {steps.map((step) => (
                <div
                  className="workflow-step"
                  key={step.number}
                >

                  <div className="step-number">
                    {step.number}
                  </div>

                  <div>
                    <h3>
                      {step.title}
                    </h3>

                    <p>
                      {step.description}
                    </p>
                  </div>

                </div>
              ))}

            </div>

          </div>
        </section>

        {/* CTA */}
        <section
          id="about"
          className="cta-section"
        >
          <div className="cta-card">

            <div className="cta-glow"></div>

            <div className="cta-content">

              <div className="section-label">
                START YOUR CAREER ANALYSIS
              </div>

              <h2>
                Stop guessing.
                <span>Start building with direction.</span>
              </h2>

              <p>
                Create your profile, analyze your current skills and
                discover the next steps toward your desired career.
              </p>

              <Link
                to="/roles"
                className="primary-button"
              >
                Get Started
                <span>→</span>
              </Link>

            </div>

          </div>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="landing-footer">
        <div className="landing-container footer-inner">

          <div className="footer-brand">
            <div className="brand-mark small">
              CC
            </div>

            <div>
              <strong>
                CareerCompass AI
              </strong>

              <p>
                AI-powered career intelligence platform.
              </p>
            </div>
          </div>

          <div className="footer-text">
            Career guidance powered by data, machine learning
            and your profile.
          </div>

        </div>
      </footer>

    </div>
  );
}

export default Landing;