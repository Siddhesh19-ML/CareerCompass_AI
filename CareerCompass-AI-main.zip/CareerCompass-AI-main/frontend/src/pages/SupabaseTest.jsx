import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function SupabaseTest() {
  const [status, setStatus] = useState("Testing connection...");
  const [error, setError] = useState("");

  useEffect(() => {
    async function testConnection() {
      try {
        const { data, error } = await supabase.auth.getSession();

        if (error) {
          throw error;
        }

        setStatus("Supabase connection successful.");
        console.log("Supabase session:", data);
      } catch (err) {
        console.error("Supabase connection error:", err);
        setStatus("Supabase connection failed.");
        setError(err.message);
      }
    }

    testConnection();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-6">
      <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center shadow-xl">
        <h1 className="text-2xl font-bold text-white">
          CareerCompass AI
        </h1>

        <p className="mt-3 text-slate-400">
          Supabase Connection Test
        </p>

        <div
          className={`mt-6 rounded-xl px-4 py-4 ${
            error
              ? "bg-red-500/10 text-red-400"
              : "bg-emerald-500/10 text-emerald-400"
          }`}
        >
          {status}
        </div>

        {error && (
          <p className="mt-4 text-sm text-red-400">
            {error}
          </p>
        )}
      </div>
    </div>
  );
}