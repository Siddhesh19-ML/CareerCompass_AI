import { useEffect, useState } from "react";
import {useNavigate,useLocation,} from "react-router-dom";
import "./Dashboard.css";
import { supabase } from "../lib/supabase";
import { logoutUser } from "../services/authService";
import { getStudentProfile } from "../services/profileService";
import {
  analyzeCareer,
  saveCareerAnalysis,
  getLatestCareerAnalysis,
} from "../services/analysisService";

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();

  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);

  const [analysis, setAnalysis] = useState(null);

  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  const [error, setError] = useState("");

  // ==========================================
  // LOAD USER + PROFILE
  // ==========================================

  useEffect(() => {
    async function loadDashboard() {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        setUser(user);

        const savedProfile = await getStudentProfile();

        setProfile(savedProfile);

        // ------------------------------------------
        // LOAD PREVIOUS CAREER ANALYSIS
        // ------------------------------------------

        // ------------------------------------------
        // LOAD ANALYSIS
        // ------------------------------------------

        if (location.state?.historicalAnalysis) {

            setAnalysis(
                location.state.historicalAnalysis
            );

        } else {

            const latestAnalysis =
                await getLatestCareerAnalysis();

            if (latestAnalysis) {
                setAnalysis(latestAnalysis);
            }
        }
      } catch (err) {
        console.error(err);

        setError(
          "Unable to load your career profile."
        );
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, [location.state]);

  // ==========================================
  // ANALYZE CAREER
  // ==========================================

  async function handleAnalyze() {
    if (!profile?.profile_data) {
      setError(
        "Please complete your career profile first."
      );
      return;
    }

    const desiredCareer =
      profile.profile_data.desired_career;

    if (!desiredCareer) {
      setError(
        "Please select your desired career in your profile first."
      );
      return;
    }

    setAnalyzing(true);
    setError("");

    try {
      const result = await analyzeCareer(
        profile.profile_data,
        desiredCareer
      );

      await saveCareerAnalysis(result);

      console.log(
        "Career analysis result:",
        result
      );

      setAnalysis(result);
    } catch (err) {
      console.error(
        "Career analysis error:",
        err
      );

      setError(
        err.response?.data?.detail ||
        err.message ||
        "Unable to analyze your career."
      );
    } finally {
      setAnalyzing(false);
    }
  }

  // ==========================================
  // LOGOUT
  // ==========================================

  async function handleLogout() {
    try {
      await logoutUser();

      navigate("/login");
    } catch (err) {
      console.error(err);
    }
  }

  // ==========================================
  // LOADING SCREEN
  // ==========================================

  if (loading) {
    return (
      <div className="app-loading">
        <div className="loading-content">

          <div className="loading-spinner" />

          <h2>CareerCompass AI</h2>

          <p>
            Loading your career profile...
          </p>

        </div>
      </div>
    );
  }

  // ==========================================
  // ANALYSIS DATA
  // ==========================================

  const prediction =
    analysis?.prediction;

  const alignment =
    analysis?.alignment;

  const skillGap =
    analysis?.skill_gap;

  const roadmap =
    analysis?.roadmap;

  // ==========================================
  // DASHBOARD
  // ==========================================

  return (
    <div className="dashboard-page">

      {/* ======================================
          HEADER
      ====================================== */}

      <header className="dashboard-header">

        <div>

          <h1>
            CareerCompass AI
          </h1>

          <p>
            Your career intelligence dashboard
          </p>

        </div>

        <div className="dashboard-actions">

            <button
                className="secondary-button"
                onClick={() => navigate("/history")}
            >
                Analysis History
            </button>

            <button
                className="secondary-button"
                onClick={() => navigate("/profile")}
            >
                Edit Profile
            </button>

            <button
                className="secondary-button"
                onClick={handleLogout}
            >
                Sign Out
            </button>

        </div>

      </header>

      <main className="analysis-container">

        {/* ======================================
            INTRO
        ====================================== */}

        <section className="analysis-intro">

          <p className="eyebrow">
            CAREER DASHBOARD
          </p>

          <h2>
            Your Career Analysis
          </h2>

          <p>
            Here is what CareerCompass AI
            found from your profile.
          </p>

        </section>

        {/* ======================================
            ERROR
        ====================================== */}

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        {/* ======================================
            BEFORE ANALYSIS
        ====================================== */}

        {!analysis && (

          <section className="analysis-start-card">

            <div>

              <h3>
                Your profile is ready
              </h3>

              <p>
                Analyze your skills, experience
                and academic profile to discover
                the careers that best match you.
              </p>

            </div>

            <button
              className="primary-button analyze-button"
              onClick={handleAnalyze}
              disabled={analyzing}
            >
              {analyzing
                ? "Analyzing..."
                : "Analyze My Career"}
            </button>

          </section>

        )}

        {/* ======================================
            ANALYSIS RESULTS
        ====================================== */}

        {analysis && (

          <>

            {/* ==================================
                TOP CARDS
            ================================== */}

            <section className="analysis-top-grid">

              {/* BEST CAREER */}

              <div className="analysis-card">

                <p className="card-label">
                  Best Career Match
                </p>

                <h3>
                  {prediction?.best_career}
                </h3>

                <p className="card-description">
                  Based on your current profile
                </p>

                <div className="metric-row">

                  <span>
                    Confidence
                  </span>

                  <strong>
                    {prediction?.confidence}%
                  </strong>

                </div>

                <div className="progress-track">

                  <div
                    className="progress-fill blue"
                    style={{
                      width: `${Math.min(
                        prediction?.confidence || 0,
                        100
                      )}%`,
                    }}
                  />

                </div>

              </div>

              {/* DESIRED CAREER */}

              <div className="analysis-card">

                <p className="card-label">
                  Desired Career
                </p>

                <h3>
                  {analysis.desired_career}
                </h3>

                <p className="card-description">
                  Your selected career goal
                </p>

                <div className="metric-row">

                  <span>
                    Skill Match
                  </span>

                  <strong>
                    {alignment?.skill_match}%
                  </strong>

                </div>

                <div className="progress-track">

                  <div
                    className="progress-fill orange"
                    style={{
                      width: `${Math.min(
                        alignment?.skill_match || 0,
                        100
                      )}%`,
                    }}
                  />

                </div>

              </div>

              {/* ALIGNMENT */}

              <div className="analysis-card">

                <p className="card-label">
                  Career Alignment
                </p>

                <h3
                  className={`alignment-${(
                    alignment?.level || ""
                  ).toLowerCase()}`}
                >
                  {alignment?.level}
                </h3>

                <p className="card-description">
                  {alignment?.message}
                </p>

              </div>

            </section>

            {/* ==================================
                CAREER PREDICTIONS + SKILL GAP
            ================================== */}

            <section className="analysis-two-column">

              {/* TOP CAREERS */}

              <div className="analysis-panel">

                <h3>
                  Top Career Predictions
                </h3>

                <p className="panel-description">
                  Careers your profile currently
                  matches
                </p>

                <div className="career-list">

                  {prediction?.top_careers?.map(
                    (career, index) => (

                      <div
                        className="career-item"
                        key={career.career}
                      >

                        <div className="career-item-header">

                          <span>
                            {index + 1}.{" "}
                            {career.career}
                          </span>

                          <strong>
                            {career.probability}%
                          </strong>

                        </div>

                        <div className="progress-track">

                          <div
                            className="progress-fill blue"
                            style={{
                              width: `${Math.min(
                                career.probability,
                                100
                              )}%`,
                            }}
                          />

                        </div>

                      </div>

                    )
                  )}

                </div>

              </div>

              {/* SKILL GAP */}

              <div className="analysis-panel">

                <h3>
                  Priority Skill Gaps
                </h3>

                <p className="panel-description">
                  Skills to focus on for{" "}
                  {analysis.desired_career}
                </p>

                <div className="skill-gap-grid">

                  {skillGap?.missing_skills
                    ?.slice(0, 10)
                    .map((skill) => (

                      <div
                        className="skill-gap"
                        key={skill.skill}
                      >

                        <div className="skill-gap-name">
                          {skill.skill}
                        </div>

                        <div className="skill-gap-details">
                          Current:{" "}
                          {skill.current_level}
                          {" · "}
                          Required:{" "}
                          {skill.required_level}
                        </div>

                      </div>

                    ))}

                </div>

              </div>

            </section>

            {/* ==================================
                SHAP EXPLANATION
            ================================== */}

            {analysis.explanation && (

              <section className="analysis-two-column">

                {/* POSITIVE FACTORS */}

                <div className="analysis-panel">

                  <h3>
                    Why This Career?
                  </h3>

                  <p className="panel-description">
                    Factors contributing most to
                    your predicted career
                  </p>

                  <div className="factor-list">

                    {analysis.explanation
                      .positive_factors
                      ?.map((factor) => (

                        <div
                          className="factor positive-factor"
                          key={factor.feature}
                        >

                          <div>

                            <strong>
                              {factor.feature}
                            </strong>

                            <span>
                              Current value:{" "}
                              {factor.value}
                            </span>

                          </div>

                          <strong>
                            +{factor.impact}
                          </strong>

                        </div>

                      ))}

                  </div>

                </div>

                {/* NEGATIVE FACTORS */}

                <div className="analysis-panel">

                  <h3>
                    Areas Holding You Back
                  </h3>

                  <p className="panel-description">
                    Factors currently reducing your
                    career match
                  </p>

                  <div className="factor-list">

                    {analysis.explanation
                      .negative_factors
                      ?.map((factor) => (

                        <div
                          className="factor negative-factor"
                          key={factor.feature}
                        >

                          <div>

                            <strong>
                              {factor.feature}
                            </strong>

                            <span>
                              Current value:{" "}
                              {factor.value}
                            </span>

                          </div>

                          <strong>
                            {factor.impact}
                          </strong>

                        </div>

                      ))}

                  </div>

                </div>

              </section>

            )}

            {/* ==================================
                ROADMAP
            ================================== */}

            <section className="analysis-panel roadmap-panel">

              <div className="roadmap-heading">

                <div>

                  <h3>
                    Personalized Roadmap
                  </h3>

                  <p className="panel-description">
                    Recommended path toward{" "}
                    {analysis.desired_career}
                  </p>

                </div>

                <span className="roadmap-duration">
                  {roadmap?.length || 0} Months
                </span>

              </div>

              <div className="roadmap-grid">

                {roadmap?.map((month) => (

                  <div
                    className="roadmap-month"
                    key={month.month}
                  >

                    <h4>
                      Month {month.month}
                    </h4>

                    {month.topics?.map(
                      (topic) => (

                        <div
                          className="roadmap-skill"
                          key={topic.skill}
                        >

                          <strong>
                            {topic.title}
                          </strong>

                          <span>
                            Duration:{" "}
                            {topic.duration}
                          </span>

                          {topic.prerequisite && (

                            <span>
                              Prerequisite:{" "}
                              {topic.prerequisite}
                            </span>

                          )}

                        </div>

                      )
                    )}

                  </div>

                ))}

              </div>

            </section>

            {/* ==================================
                RE-ANALYZE
            ================================== */}

            <div className="reanalyze-container">

              <button
                className="secondary-button"
                onClick={handleAnalyze}
                disabled={analyzing}
              >

                {analyzing
                  ? "Analyzing..."
                  : "Re-analyze Career"}

              </button>

            </div>

          </>

        )}

      </main>

    </div>
  );
}