import { useState } from "react";
import {
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";

import {
  FaArrowRight,
  FaBrain,
  FaBuilding,
  FaCheck,
  FaRobot,
  FaUserGraduate,
} from "react-icons/fa";

import { motion } from "framer-motion";

import {
  getCurrentUser,
  setUserRole,
} from "../services/authService";

import "./RoleSelection.css";

export default function RoleSelection() {
  const navigate = useNavigate();
  const location = useLocation();

  const [selectedRole, setSelectedRole] =
    useState("student");

  const [saving, setSaving] = useState(false);

  // ==========================================
  // AVAILABLE ROLES
  // ==========================================

  const roles = [
    {
      id: "student",
      icon: FaUserGraduate,
      title: "Student",
      description:
        "Analyze your skills, academics, projects and experience to discover suitable career paths.",
      features: [
        "AI career prediction",
        "Resume analysis",
        "Skill gap analysis",
        "Personalized learning roadmap",
      ],
    },

    {
      id: "recruiter",
      icon: FaBuilding,
      title: "Recruiter",
      description:
        "Evaluate candidate profiles and identify students whose skills align with your requirements.",
      features: [
        "Candidate profiles",
        "Skill-based matching",
        "Candidate intelligence",
        "Recruitment insights",
      ],
    },
  ];

  // ==========================================
  // CONTINUE
  // ==========================================

  const handleContinue = async () => {
    if (saving) {
      return;
    }

    try {
      setSaving(true);

      // ==========================================
      // CHECK WHETHER USER IS ALREADY LOGGED IN
      // ==========================================

      const user = await getCurrentUser();

      // ==========================================
      // EXISTING AUTHENTICATED USER
      // ==========================================

      if (user) {
        await setUserRole(selectedRole);

        // ------------------------------------------
        // User came here after registration
        // ------------------------------------------

        if (location.state?.from === "register") {
          navigate("/profile");
          return;
        }

        // ------------------------------------------
        // User came here after login
        // ------------------------------------------

        if (location.state?.from === "login") {
          navigate("/dashboard");
          return;
        }

        // ------------------------------------------
        // Default authenticated flow
        // ------------------------------------------

        navigate("/dashboard");
        return;
      }

      // ==========================================
      // NEW / NOT AUTHENTICATED USER
      // ==========================================

      /*
       * The user has selected a role but does not
       * have a Supabase account yet.
       *
       * We temporarily store the role in sessionStorage.
       *
       * This is ONLY temporary.
       * The permanent role will be saved to Supabase
       * after registration/login.
       */

      sessionStorage.setItem(
        "careercompass_pending_role",
        selectedRole
      );

      // ==========================================
      // GO TO REGISTRATION
      // ==========================================

      navigate("/register", {
        state: {
          role: selectedRole,
        },
      });
    } catch (err) {
      console.error(
        "Role selection error:",
        err
      );
    } finally {
      setSaving(false);
    }
  };

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <div className="role-page">

      {/* ==========================================
          BACKGROUND
      ========================================== */}

      <div className="role-background">

        <div className="role-glow role-glow-one"></div>

        <div className="role-glow role-glow-two"></div>

        <div className="role-grid"></div>

      </div>


      {/* ==========================================
          NAVBAR
      ========================================== */}

      <nav className="role-navbar">

        <div className="role-navbar-inner">

          <Link
            to="/"
            className="role-brand"
          >

            <div className="role-brand-icon">
              <FaRobot />
            </div>

            <div>

              <div className="role-brand-name">
                CareerCompass AI
              </div>

              <div className="role-brand-subtitle">
                CAREER INTELLIGENCE
              </div>

            </div>

          </Link>


          <Link
            to="/login"
            className="role-signin"
          >
            Sign in
          </Link>

        </div>

      </nav>


      {/* ==========================================
          MAIN
      ========================================== */}

      <main className="role-main">

        <div className="role-content">


          {/* ==========================================
              HEADER
          ========================================== */}

          <motion.div
            className="role-header"

            initial={{
              opacity: 0,
              y: 25,
            }}

            animate={{
              opacity: 1,
              y: 0,
            }}

            transition={{
              duration: 0.6,
            }}
          >

            <div className="role-main-icon">
              <FaBrain />
            </div>


            <div className="role-label">

              <span></span>

              GET STARTED

            </div>


            <h1>
              Choose your role
            </h1>


            <p>
              Tell CareerCompass AI how you will use
              the platform. Your experience will be
              personalized around your selected role.
            </p>

          </motion.div>


          {/* ==========================================
              ROLE CARDS
          ========================================== */}

          <div className="role-cards">

            {roles.map((role, index) => {

              const Icon = role.icon;

              const isSelected =
                selectedRole === role.id;

              return (

                <motion.button
                  key={role.id}

                  type="button"

                  className={`role-card ${
                    isSelected
                      ? "role-card-selected"
                      : ""
                  }`}

                  initial={{
                    opacity: 0,
                    y: 30,
                  }}

                  animate={{
                    opacity: 1,
                    y: 0,
                  }}

                  transition={{
                    duration: 0.5,
                    delay: index * 0.1,
                  }}

                  onClick={() =>
                    setSelectedRole(role.id)
                  }

                  disabled={saving}
                >

                  {/* ==================================
                      SELECTION
                  ================================== */}

                  <div
                    className={`role-check ${
                      isSelected
                        ? "role-check-selected"
                        : ""
                    }`}
                  >

                    {isSelected && (
                      <FaCheck />
                    )}

                  </div>


                  {/* ==================================
                      SELECTED GLOW
                  ================================== */}

                  {isSelected && (
                    <div className="role-card-glow"></div>
                  )}


                  <div className="role-card-content">


                    {/* ==================================
                        ICON
                    ================================== */}

                    <div
                      className={`role-icon ${
                        isSelected
                          ? "role-icon-selected"
                          : ""
                      }`}
                    >
                      <Icon />
                    </div>


                    {/* ==================================
                        TITLE
                    ================================== */}

                    <h2>
                      {role.title}
                    </h2>


                    {/* ==================================
                        DESCRIPTION
                    ================================== */}

                    <p className="role-description">
                      {role.description}
                    </p>


                    {/* ==================================
                        FEATURES
                    ================================== */}

                    <div className="role-features">

                      {role.features.map(
                        (feature) => (

                          <div
                            className="role-feature"
                            key={feature}
                          >

                            <div
                              className={`feature-check ${
                                isSelected
                                  ? "feature-check-selected"
                                  : ""
                              }`}
                            >

                              <FaCheck />

                            </div>


                            <span>
                              {feature}
                            </span>

                          </div>

                        )
                      )}

                    </div>

                  </div>

                </motion.button>

              );

            })}

          </div>


          {/* ==========================================
              CONTINUE
          ========================================== */}

          <motion.div
            className="role-continue"

            initial={{
              opacity: 0,
              y: 15,
            }}

            animate={{
              opacity: 1,
              y: 0,
            }}

            transition={{
              delay: 0.4,
            }}
          >

            <button
              type="button"

              className="role-continue-button"

              onClick={handleContinue}

              disabled={saving}
            >

              {saving
                ? "Saving..."
                : "Continue as"
              }

              {!saving && (
                <>
                  {" "}

                  {selectedRole === "student"
                    ? "Student"
                    : "Recruiter"
                  }

                  <FaArrowRight />
                </>
              )}

            </button>


            <p>
              You can update your role later from
              your profile.
            </p>

          </motion.div>

        </div>

      </main>

    </div>
  );
}