import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./History.css";

import {
  getCareerAnalysisHistory,
} from "../services/analysisService";

export default function History() {
  const navigate = useNavigate();

  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadHistory() {
      try {
        const data =
          await getCareerAnalysisHistory();

        setHistory(data);
      } catch (err) {
        console.error(err);
        setError(
          err.message ||
            "Unable to load analysis history."
        );
      } finally {
        setLoading(false);
      }
    }

    loadHistory();
  }, []);

  function openAnalysis(item) {
    if (!item.analysis_data) {
        return;
    }

     navigate("/dashboard", {
        state: {
            historicalAnalysis: item.analysis_data,
        },
     });
    }

  function formatDate(date) {
    return new Date(date).toLocaleString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  if (loading) {
    return (
      <div className="app-loading">
        <div className="loading-content">
          <div className="loading-spinner"></div>

          <h2>CareerCompass AI</h2>

          <p>Loading your analysis history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="history-page">

      <div className="history-container">

        <div className="history-header">

          <div>
            <div className="section-label">
              CAREER INTELLIGENCE
            </div>

            <h1>
              Analysis History
            </h1>

            <p>
              Review your previous CareerCompass
              AI analyses.
            </p>
          </div>

          <button
            className="secondary-button"
            onClick={() =>
              navigate("/dashboard")
            }
          >
            Back to Dashboard
          </button>

        </div>

        {error && (
          <div className="history-error">
            {error}
          </div>
        )}

        {!error && history.length === 0 && (
          <div className="empty-history">

            <h2>
              No analyses yet
            </h2>

            <p>
              Analyze your career profile to
              create your first career analysis.
            </p>

            <button
              className="primary-button"
              onClick={() =>
                navigate("/dashboard")
              }
            >
              Analyze My Career
            </button>

          </div>
        )}

        <div className="history-list">

          {history.map((item) => (

            <div
              className="history-card"
              key={item.id}
            >

              <div className="history-card-top">

                <div>
                  <span className="history-date">
                    {formatDate(
                      item.created_at
                    )}
                  </span>

                  <h2>
                    {item.predicted_career ||
                      "Career Analysis"}
                  </h2>
                </div>

                <span
                  className={
                    "alignment-badge " +
                    (
                      item.alignment_level ||
                      "Unknown"
                    ).toLowerCase()
                  }
                >
                  {item.alignment_level ||
                    "Unknown"}
                </span>

              </div>

              <div className="history-stats">

                <div>
                  <span>
                    Desired Career
                  </span>

                  <strong>
                    {item.desired_career ||
                      "Not specified"}
                  </strong>
                </div>

                <div>
                  <span>
                    Confidence
                  </span>

                  <strong>
                    {Number(
                      item.confidence || 0
                    ).toFixed(2)}
                    %
                  </strong>
                </div>

                <div>
                  <span>
                    Skill Match
                  </span>

                  <strong>
                    {Number(
                      item.skill_match || 0
                    ).toFixed(2)}
                    %
                  </strong>
                </div>

              </div>

              {item.alignment_message && (
                <p className="history-message">
                  {item.alignment_message}
                </p>
              )}

              <div className="history-actions">

                <button
                  className="primary-button"
                  disabled={!item.analysis_data}
                  onClick={() =>
                    openAnalysis(item)
                  }
                >
                  View Analysis
                </button>

              </div>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}