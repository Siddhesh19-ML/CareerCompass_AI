import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  loginUser,
  getUserRole,
} from "../services/authService";
import "./Auth.css";

export default function Login() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function handleChange(e) {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      await loginUser(formData);

      const role = await getUserRole();

      if (role) {
        // Existing account with a role
        navigate("/dashboard");
      } else {
        // Account exists but role has not been selected
        navigate("/role-selection", {
          state: {
            from: "login",
          },
        });
      }
    } catch (err) {
      setError(
        err.message ||
          "Unable to sign in. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">

      {/* Background effects */}
      <div className="auth-glow auth-glow-one"></div>
      <div className="auth-glow auth-glow-two"></div>

      {/* Top navigation */}
      <header className="auth-navbar">

        <div className="auth-navbar-inner">

          <Link to="/" className="auth-brand">

            <div className="auth-brand-mark">
              CC
            </div>

            <div>
              <div className="auth-brand-name">
                CareerCompass AI
              </div>

              <div className="auth-brand-subtitle">
                CAREER INTELLIGENCE
              </div>
            </div>

          </Link>

          <Link
            to="/"
            className="auth-back"
          >
            Back to home
          </Link>

        </div>

      </header>

      {/* Main */}
      <main className="auth-main">

        <div className="auth-layout">

          {/* Left information panel */}
          <section className="auth-intro">

            <div className="auth-label">
              <span className="auth-status-dot"></span>
              CAREER INTELLIGENCE PLATFORM
            </div>

            <h1>
              Your career journey
              <span> starts here.</span>
            </h1>

            <p>
              Sign in to access your CareerCompass profile,
              career analysis, skill insights and personalized
              learning roadmap.
            </p>

            <div className="auth-benefits">

              <div className="auth-benefit">
                <div className="auth-benefit-number">
                  01
                </div>

                <div>
                  <strong>
                    AI Career Analysis
                  </strong>

                  <p>
                    Understand which career paths best match your profile.
                  </p>
                </div>
              </div>

              <div className="auth-benefit">
                <div className="auth-benefit-number">
                  02
                </div>

                <div>
                  <strong>
                    Skill Gap Intelligence
                  </strong>

                  <p>
                    Identify the skills you need to develop next.
                  </p>
                </div>
              </div>

              <div className="auth-benefit">
                <div className="auth-benefit-number">
                  03
                </div>

                <div>
                  <strong>
                    Personalized Roadmap
                  </strong>

                  <p>
                    Follow a structured path toward your target career.
                  </p>
                </div>
              </div>

            </div>

          </section>

          {/* Login card */}
          <section className="auth-card">

            <div className="auth-card-top">

              <div className="auth-card-icon">
                CC
              </div>

              <div className="auth-secure">
                SECURE SIGN IN
              </div>

            </div>

            <div className="auth-header">

              <h2>
                Welcome back
              </h2>

              <p>
                Sign in to continue your career journey.
              </p>

            </div>

            {error && (
              <div className="auth-error">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit}>

              <div className="form-group">

                <label htmlFor="email">
                  Email address
                </label>

                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  autoComplete="email"
                  required
                />

              </div>

              <div className="form-group">

                <div className="password-label">

                  <label htmlFor="password">
                    Password
                  </label>

                  <button
                    type="button"
                    className="forgot-button"
                    onClick={() =>
                      navigate("/forgot-password")
                    }
                  >
                    Forgot password?
                  </button>

                </div>

                <input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleChange}
                  autoComplete="current-password"
                  required
                />

              </div>

              <button
                type="submit"
                className="auth-submit"
                disabled={loading}
              >
                {loading ? (
                  <span className="submit-content">
                    <span className="loading-spinner"></span>
                    Signing in...
                  </span>
                ) : (
                  <span className="submit-content">
                    Sign In
                    <span className="submit-arrow">
                      →
                    </span>
                  </span>
                )}
              </button>

            </form>

            <div className="auth-divider">
              <span>
                New to CareerCompass AI?
              </span>
            </div>

            <Link
              to="/register"
              className="auth-secondary-button"
            >
              Create an account
              <span>→</span>
            </Link>

            <div className="auth-security-note">
              <span className="security-dot"></span>

              Your profile and career analysis are securely
              associated with your account.
            </div>

          </section>

        </div>

      </main>

    </div>
  );
}