import { useState } from "react";
import {
  uploadResume,
  getResumeUrl,
} from "../services/profileService";
import "./ResumeUpload.css";

const API_URL = "http://127.0.0.1:8000";

export default function ResumeUpload({ onExtracted }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  function handleFileChange(e) {
    const selectedFile = e.target.files?.[0] || null;

    setFile(selectedFile);
    setMessage("");
    setError("");

    if (selectedFile && selectedFile.type !== "application/pdf") {
      setError("Please select a PDF file.");
      setFile(null);
    }
  }

  async function handleUpload() {
    if (!file) {
      setError("Please select your PDF resume first.");
      return;
    }

    try {
      setUploading(true);
      setError("");
      setMessage("");

      // Upload resume to Supabase Storage
      const filePath = await uploadResume(file);

      // Get signed URL
      const signedUrl = await getResumeUrl(filePath);

      // Send resume to FastAPI
      const response = await fetch(
        `${API_URL}/resume-parse`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            resume_url: signedUrl,
          }),
        }
      );

      if (!response.ok) {
        let errorMessage = "Resume parsing failed.";

        try {
          const data = await response.json();
          errorMessage = data.detail || errorMessage;
        } catch {
          // Keep default error message
        }

        throw new Error(errorMessage);
      }

      const result = await response.json();

      console.log("Extracted resume data:", result);

      setMessage(
        "Resume uploaded and analyzed successfully."
      );

      if (onExtracted) {
        onExtracted(result);
      }

    } catch (err) {
      console.error("Resume upload error:", err);

      setError(
        err.message || "Unable to upload resume."
      );

    } finally {
      setUploading(false);
    }
  }

  return (
    <section className="profile-section resume-section">

      <div className="section-heading">
        <h3>Resume</h3>

        <p>
          Upload your latest PDF resume to automatically
          extract your skills and experience.
        </p>
      </div>

      <div className="resume-upload-container">

        <div className="resume-upload-content">

          <div className="resume-icon">
            PDF
          </div>

          <div className="resume-upload-text">

            <strong>
              Upload your resume
            </strong>

            <span>
              PDF files only · Maximum recommended size: 5 MB
            </span>

          </div>

        </div>

        <div className="resume-file-row">

          <input
            id="resume-file"
            type="file"
            accept=".pdf,application/pdf"
            onChange={handleFileChange}
            className="resume-file-input"
          />

          <label
            htmlFor="resume-file"
            className="resume-select-button"
          >
            Choose PDF
          </label>

          {file && (
            <span className="selected-file">
              {file.name}
            </span>
          )}

          {!file && (
            <span className="no-file">
              No file selected
            </span>
          )}

        </div>

        {file && (
          <button
            type="button"
            className="primary-button resume-upload-button"
            onClick={handleUpload}
            disabled={uploading}
          >
            {uploading
              ? "Processing Resume..."
              : "Upload & Analyze Resume"}
          </button>
        )}

        {message && (
          <div className="success-message resume-message">
            {message}
          </div>
        )}

        {error && (
          <div className="error-message resume-message">
            {error}
          </div>
        )}

      </div>

    </section>
  );
}